import 'package:dirronlive/core/events/delivery_status.dart';
import 'package:dirronlive/core/events/event_source.dart';
import 'package:dirronlive/core/events/gift_event.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  final event = GiftEvent(
    id: generateEventId(),
    createdAt: DateTime(2026, 11, 23, 0, 31, 5, 123, 456),
    source: EventSource.test,
    viewerName: 'Тестовый зритель',
    giftName: 'Роза',
    count: 1,
  );

  test('текст для ленты совпадает с заданием', () {
    expect(event.feedText, 'Тестовый зритель отправил подарок „Роза“ ×1');
  });

  test('источник test показывается как «Тест»', () {
    expect(event.source.id, 'test');
    expect(event.source.label, 'Тест');
  });

  test('JSON туда и обратно без потерь', () {
    expect(GiftEvent.fromJson(event.toJson()), event);
  });

  test('запись первой версии без поля delivery → «Только в журнале»', () {
    final v1 = event.toJson()..remove('delivery');
    final parsed = GiftEvent.fromJson(v1);
    expect(parsed.delivery, DeliveryStatus.logOnly);
    expect(parsed.delivery.label, 'Только в журнале');
  });

  test('все статусы доставки сохраняются и читаются', () {
    for (final status in DeliveryStatus.values) {
      final withStatus = event.copyWith(delivery: status);
      expect(GiftEvent.fromJson(withStatus.toJson()).delivery, status);
    }
    expect(DeliveryStatus.fromId('что-то новое'), DeliveryStatus.logOnly);
  });

  test('комбо и число доставленных сохраняются', () {
    final combo = GiftEvent(
      id: generateEventId(),
      createdAt: DateTime(2026, 11, 23, 3, 0),
      source: EventSource.test,
      viewerName: 'Тестовый зритель',
      giftName: 'Роза',
      count: 15,
      delivery: DeliveryStatus.partial,
      comboId: 'combo',
      comboActive: true,
      deliveredCount: 10,
    );
    final parsed = GiftEvent.fromJson(combo.toJson());
    expect(parsed, combo);
    expect(parsed.deliveryLabel, 'Доставлено 10 из 15');
    expect(parsed.giftText, 'Роза ×15');
  });

  test('запись 0.2.0 «Доставлено» без deliveredCount — доставлено всё', () {
    final v2 = event.copyWith(delivery: DeliveryStatus.delivered).toJson()
      ..remove('deliveredCount');
    final parsed = GiftEvent.fromJson(v2);
    expect(parsed.deliveredCount, parsed.count);
    expect(parsed.isCombo, isFalse);
  });

  test('id уникальны и в формате UUID v4', () {
    final ids = {for (var i = 0; i < 10000; i++) generateEventId()};
    expect(ids.length, 10000);
    final uuid = RegExp(
        r'^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$');
    expect(ids.every(uuid.hasMatch), isTrue);
  });

  test('повреждённые записи отклоняются', () {
    final good = event.toJson();
    for (final broken in <Object?>[
      null,
      'строка',
      {...good, 'id': ''},
      {...good, 'createdAt': 'вчера'},
      {...good, 'source': 'unknown'},
      {...good, 'count': 0},
      {...good, 'count': '1'},
      {...good}..remove('giftName'),
    ]) {
      expect(() => GiftEvent.fromJson(broken), throwsFormatException,
          reason: '$broken');
    }
  });

  test('действие паркура и ID подарка сохраняются в истории', () {
    final withAction = event.copyWith(
      actionTitle: 'Комната назад',
      actionResult: 'Комната 12 → 11',
      actionState: ActionState.done,
    );
    final parsed = GiftEvent.fromJson(withAction.toJson());
    expect(parsed, withAction);
    expect(parsed.actionText, 'Тест · Комната 12 → 11');

    final pending = GiftEvent.fromJson({
      ...event.toJson(),
      'giftId': '5655',
      'actionState': 'pending',
      'actionTitle': 'Толчок',
    });
    expect(pending.giftId, '5655');
    expect(pending.actionText, '«Толчок» → отправляется');
    // Старые записи без полей действия читаются как раньше.
    expect(GiftEvent.fromJson(event.toJson()).actionText, isNull);
  });
}
