// Раскладка в окнах 1920×1080 и 1024×700: верхняя навигация, кнопка
// тестового подарка и последняя запись видны одновременно; ни один экран
// не переполняется.

import 'package:dirronlive/features/events/event_log.dart';
import 'package:dirronlive/features/navigation/app_section.dart';
import 'package:dirronlive/ui/screens/live_screen.dart';
import 'package:dirronlive/ui/screens/settings_screen.dart';
import 'package:dirronlive/ui/widgets/app_logo.dart';
import 'package:dirronlive/ui/widgets/test_gift_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/memory_store.dart';
import 'support/test_app.dart';

void main() {
  const sizes = {
    '1920×1080': Size(1920, 1080),
    '1024×700': Size(1024, 700),
  };

  sizes.forEach((name, size) {
    testWidgets('$name: навигация, кнопка и последняя запись видны сразу',
        (tester) async {
      final container =
          await pumpDirronlive(tester, MemoryJsonStore(), size: size);

      for (final section in AppSection.values) {
        expect(find.byKey(Key('nav-${section.name}')).hitTestable(),
            findsOneWidget,
            reason: '«${section.label}» в верхней строке');
      }
      expect(find.byKey(AppLogo.logoKey).hitTestable(), findsOneWidget);
      expect(find.byKey(TestGiftButton.buttonKey).hitTestable(), findsOneWidget);

      for (var i = 0; i < 12; i++) {
        await tester.tap(find.byKey(TestGiftButton.buttonKey));
        await tester.pump();
        expectNoFlutterError(tester, '$name, нажатие ${i + 1}');
      }
      await tester.pumpAndSettle();
      expectNoFlutterError(tester, '$name, после нажатий');

      final newest = container.read(eventLogProvider).events.first;
      expect(
        isFullyVisibleIn(tester, find.byKey(ValueKey(newest.id)),
            find.byKey(LiveScreen.feedKey)),
        isTrue,
        reason: 'последняя запись видна',
      );
      expect(find.byKey(TestGiftButton.buttonKey).hitTestable(), findsOneWidget);
      expect(find.byKey(const Key('nav-live')).hitTestable(), findsOneWidget);
      expect(tester.takeException(), isNull);

      for (final section in AppSection.values) {
        await openSection(tester, section.name);
        expect(tester.takeException(), isNull,
            reason: 'экран «${section.label}» при $name');
        // Навигация видна на каждом экране.
        expect(find.byKey(const Key('nav-live')).hitTestable(), findsOneWidget);
      }

      // В настройках обе секции и кнопки достижимы.
      await openSection(tester, AppSection.settings.name);
      for (final key in [
        SettingsScreen.saveButtonKey,
        SettingsScreen.linkToggleKey,
      ]) {
        await tester.ensureVisible(find.byKey(key));
        await tester.pumpAndSettle();
        expectNoFlutterError(tester, '$name, настройки $key');
        expect(find.byKey(key).hitTestable(), findsOneWidget);
      }

      await closeDirronlive(tester, container);
    });
  });

  testWidgets('1024×700: длинные статусы связи не ломают полосу', (tester) async {
    final container = await pumpDirronlive(
      tester,
      MemoryJsonStore(),
      size: const Size(1024, 700),
    );
    await openSection(tester, 'settings');
    await tester.ensureVisible(find.byKey(SettingsScreen.linkToggleKey));
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);
    await closeDirronlive(tester, container);
  });

  testWidgets('очень низкое окно: содержимое прокручивается', (tester) async {
    final container = await pumpDirronlive(
      tester,
      MemoryJsonStore(),
      size: const Size(1024, 520),
    );
    expect(tester.takeException(), isNull);
    final button = find.byKey(TestGiftButton.buttonKey);
    await tester.ensureVisible(button);
    await tester.pumpAndSettle();
    await tester.tap(button);
    await tester.pumpAndSettle();
    expect(find.text('Всего: 1'), findsOneWidget);

    for (final section in AppSection.values) {
      await openSection(tester, section.name);
      expect(tester.takeException(), isNull, reason: section.label);
    }
    await closeDirronlive(tester, container);
  });
}
