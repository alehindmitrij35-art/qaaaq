// «Небесный разлом»: протокол, настройки, подарки → действия против
// настоящего WebSocket и «поддельного мода», оверлей и экран режима.

import 'dart:convert';

import 'package:dirronlive/bootstrap.dart';
import 'package:dirronlive/core/events/event_source.dart';
import 'package:dirronlive/core/events/gift_event.dart';
import 'package:dirronlive/core/initial_data.dart';
import 'package:dirronlive/core/providers.dart';
import 'package:dirronlive/features/events/event_log.dart';
import 'package:dirronlive/features/minecraft/link_protocol.dart';
import 'package:dirronlive/features/minecraft/link_state.dart';
import 'package:dirronlive/features/minecraft/minecraft_link.dart';
import 'package:dirronlive/features/overlays/overlay_kind.dart';
import 'package:dirronlive/features/overlays/overlay_models.dart';
import 'package:dirronlive/features/overlays/overlay_server.dart';
import 'package:dirronlive/features/overlays/overlay_settings.dart';
import 'package:dirronlive/features/parkour/parkour_rules.dart';
import 'package:dirronlive/features/sky/sky_catalog.dart';
import 'package:dirronlive/features/sky/sky_engine.dart';
import 'package:dirronlive/features/sky/sky_settings.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/fake_mod.dart';
import 'support/memory_store.dart';
import 'support/test_app.dart';

Map<String, Object?> _skyStatus({String phase = 'running', int errors = 0}) => {
      'type': 'sky',
      'map': 'ready',
      'phase': phase,
      'training': false,
      'sector': 3,
      'sectors': 6,
      'ring': 2,
      'rings': 7,
      'passed': 15,
      'total': 43,
      'ms': 61000,
      'errors': errors,
      'misses': errors,
      'crashes': 0,
      'bestMs': 0,
      'countdown': 0,
      'protection': false,
      'effects': [
        {'id': 'crosswind', 'seconds': 4, 'viewer': 'Mira'},
      ],
      'queued': 1,
      'problem': '',
    };

class SkyRig {
  SkyRig._(this.container);

  static Future<SkyRig> start() async {
    final container = createAppContainer(
      await loadInitialData(MemoryJsonStore()),
      overrides: [
        minecraftLinkConfigProvider.overrideWithValue(MinecraftLinkConfig(
          port: 0,
          ackTimeout: const Duration(seconds: 1),
          pingInterval: const Duration(seconds: 1),
        )),
      ],
    );
    await container.read(minecraftLinkProvider.notifier).start();
    return SkyRig._(container);
  }

  final ProviderContainer container;
  FakeMod? mod;

  SkyEngine get engine => container.read(skyEngineProvider);
  List<GiftEvent> get events => container.read(eventLogProvider).events;
  MinecraftLinkState get link => container.read(minecraftLinkProvider);

  List<Map<String, Object?>> of(String type) => mod!.messages.where((m) => m['type'] == type).toList();

  /// Мод с «Небесным разломом», открыт мир DirronSky.
  Future<FakeMod> connectSky() async {
    final m = await FakeMod.connect(link.port!);
    m.send({
      'type': 'hello',
      'protocol': 2,
      'modVersion': '3.0.0',
      'minecraftVersion': '1.21.1',
      'worldReady': true,
      'parkourActions': true,
      'actionQueue': true,
      'sky': true,
    });
    m.send({'type': 'parkour', 'available': false});
    m.send(_skyStatus());
    mod = m;
    await waitFor(() => link.skyReady, reason: 'трасса готова');
    return m;
  }

  void gift(String name, {int count = 1, String viewer = 'Alex', String? comboId}) =>
      container.read(eventBusProvider).publish(GiftEvent(
            id: generateEventId(),
            createdAt: DateTime.now(),
            source: EventSource.tiktok,
            viewerName: viewer,
            viewerId: viewer.toLowerCase(),
            giftName: name,
            count: count,
            comboId: comboId,
            sourceKey: comboId ?? generateEventId(),
          ));

  Future<void> close() async {
    await mod?.close();
    await container.read(minecraftLinkProvider.notifier).stop();
    await container.read(eventLogProvider.notifier).flush();
    container.dispose();
  }
}

void main() {
  test('протокол: состояние, ответы на действия и команды, действие в мод', () {
    final hello = LinkProtocol.parse(jsonEncode({'type': 'hello', 'worldReady': true, 'sky': true}));
    expect((hello! as ModHello).sky, isTrue);
    final sky = (LinkProtocol.parse(jsonEncode(_skyStatus(errors: 2)))! as ModSky).info;
    expect(sky.available, isTrue);
    expect(sky.running, isTrue);
    expect(sky.sector, 3);
    expect(sky.errors, 2);
    expect(sky.effects.single.id, 'crosswind');
    expect(sky.msAt(sky.receivedAt!.add(const Duration(milliseconds: 400))), 61400);
    final ack = LinkProtocol.parse(
        jsonEncode({'type': 'skyAck', 'id': 'e1', 'action': 'storm', 'state': 'deferred', 'reason': 'идёт дорогое событие'}));
    expect((ack! as ModSkyAck).reason, 'идёт дорогое событие');
    final res = LinkProtocol.parse(jsonEncode({'type': 'skyResult', 'id': 'c1', 'cmd': 'pause', 'ok': true, 'text': 'Пауза'}));
    expect((res! as ModSkyResult).ok, isTrue);
    expect(LinkProtocol.parse(jsonEncode({'type': 'skyAck', 'state': 'started'})), isNull, reason: 'без id');
    final action = jsonDecode(LinkProtocol.skyAction(
      id: 'r#1',
      action: 'slalom',
      strength: 1.5,
      seconds: 15,
      cooldown: 45,
      repeat: 'queue',
      viewerName: 'Mira',
      label: 'Лев',
      test: false,
    )) as Map;
    expect(action['type'], 'skyAction');
    expect(action['viewer'], 'Mira');
    expect(action['repeat'], 'queue');
  });

  test('настройки: всегда 10 карточек по порядку каталога, значения в границах', () {
    final d = SkySettings.defaults();
    expect(d.cards.map((c) => c.actionId), skyActions.map((a) => a.id));
    expect(skyActions.where((a) => a.tier == SkyTier.cheap), hasLength(3));
    expect(skyActions.where((a) => a.tier == SkyTier.medium), hasLength(3));
    expect(skyActions.where((a) => a.tier == SkyTier.expensive), hasLength(4));
    final s = SkySettings.fromJson({
      'profile': 'beauty',
      'restartKey': 'F8',
      'reduceFlashes': true,
      'cards': [
        {'actionId': 'storm', 'giftName': 'Лев', 'giftId': '6064', 'strength': 9, 'seconds': 999, 'repeat': 'queue'},
        {'actionId': 'unknown'},
      ],
    });
    expect(s.cards, hasLength(10));
    final storm = s.card('storm');
    expect(storm.strength, 2.0);
    expect(storm.seconds, 120);
    expect(storm.repeat, 'queue');
    expect(storm.giftId, '6064');
    expect(s.profile, 'beauty');
    expect(s.restartKey, 'F8');
    final back = SkySettings.fromJson(jsonDecode(jsonEncode(s.toJson())) as Map<String, Object?>);
    expect(back.card('storm').giftName, 'Лев');
    expect(back.reduceFlashes, isTrue);
    expect(SkySettings.fromJson({'restartKey': 'ctrl'}).restartKey, 'R');
  });

  test('подарок → по событию на штуку; ответы мода с причинами — в истории и журнале', () async {
    final rig = await SkyRig.start();
    final mod = await rig.connectSky();
    await waitFor(() => rig.of('skySettings').isNotEmpty, reason: 'настройки в мод');
    expect(rig.of('skySettings').last['profile'], 'balance');

    final settings = rig.container.read(skySettingsProvider.notifier);
    await settings.updateCard(rig.container.read(skySettingsProvider).card('crosswind').copyWith(giftName: 'Роза'));
    rig.gift('Роза', count: 3, viewer: 'Mira');
    await waitFor(() => rig.of('skyAction').length == 3, reason: 'три действия');
    final actions = rig.of('skyAction');
    final ids = actions.map((a) => a['id'] as String).toList();
    expect(ids.toSet(), hasLength(3), reason: 'у каждой штуки свой id');
    expect(ids.every((id) => id.contains('#')), isTrue);
    expect(actions.first['action'], 'crosswind');
    expect(actions.first['viewer'], 'Mira');
    expect(actions.first['seconds'], 5);

    mod.send({'type': 'skyAck', 'id': ids[0], 'action': 'crosswind', 'state': 'accepted', 'reason': ''});
    mod.send({'type': 'skyAck', 'id': ids[0], 'action': 'crosswind', 'state': 'started', 'reason': 'Боковой ветер · 5 с'});
    mod.send({'type': 'skyAck', 'id': ids[1], 'action': 'crosswind', 'state': 'deferred', 'reason': 'перезарядка 3 с'});
    mod.send({'type': 'skyAck', 'id': ids[2], 'action': 'crosswind', 'state': 'rejected', 'reason': 'очередь заполнена'});
    await waitFor(() => rig.container.read(skyJournalProvider).length >= 4, reason: 'журнал');
    final record = rig.events.first;
    expect(record.actionTitle, 'Боковой ветер');
    expect(record.actionResult, contains('Небесный разлом'));
    expect(record.actionResult, contains('в очереди 1'));
    expect(record.actionResult, contains('отклонено 1'));
    expect(record.actionState, ActionState.pending);
    final journal = rig.container.read(skyJournalProvider);
    expect(journal.any((e) => e.state == 'deferred' && e.reason == 'перезарядка 3 с'), isTrue);
    expect(journal.first.viewer, 'Mira');

    await rig.close();
  });

  test('в мире неба паркур молчит; без мира неба молчит небо', () async {
    final rig = await SkyRig.start();
    await rig.connectSky();
    await rig.container.read(parkourRulesProvider.notifier).upsert(GiftRule(
          id: 'card-x',
          giftName: 'Роза',
          actionId: 'push',
          params: const {'direction': 'left', 'strength': 1},
        ));
    final settings = rig.container.read(skySettingsProvider.notifier);
    await settings.updateCard(rig.container.read(skySettingsProvider).card('tailwind').copyWith(giftName: 'Роза'));
    rig.gift('Роза');
    await waitFor(() => rig.of('skyAction').length == 1, reason: 'действие неба');
    await Future<void>.delayed(const Duration(milliseconds: 100));
    expect(rig.of('action'), isEmpty, reason: 'паркур не отправлял');

    // Мир закрыли — небо больше не отвечает на подарки.
    rig.mod!.send({'type': 'world', 'worldReady': false});
    await waitFor(() => !rig.link.skyReady, reason: 'мир закрыт');
    rig.gift('Роза', viewer: 'Neo');
    await Future<void>.delayed(const Duration(milliseconds: 100));
    expect(rig.of('skyAction'), hasLength(1));
    await rig.close();
  });

  test('команды заезда и «Проверить»: ответ мода возвращается на экран', () async {
    final rig = await SkyRig.start();
    final mod = await rig.connectSky();
    final pending = rig.engine.command('pause');
    await waitFor(() => rig.of('skyCommand').isNotEmpty, reason: 'команда в мод');
    final cmd = rig.of('skyCommand').single;
    expect(cmd['cmd'], 'pause');
    mod.send({'type': 'skyResult', 'id': cmd['id'], 'cmd': 'pause', 'ok': true, 'text': 'Пауза'});
    expect(await pending, (true, 'Пауза'));

    final card = rig.container.read(skySettingsProvider).card('guardian');
    final testing = rig.engine.test(card);
    await waitFor(() => rig.of('skyAction').isNotEmpty, reason: 'проверка в мод');
    final a = rig.of('skyAction').single;
    expect(a['test'], isTrue);
    mod.send({'type': 'skyAck', 'id': a['id'], 'action': 'guardian', 'state': 'accepted', 'reason': ''});
    mod.send({'type': 'skyAck', 'id': a['id'], 'action': 'guardian', 'state': 'started', 'reason': 'Ангел-хранитель · 30 с'});
    final r = await testing;
    expect(r.$1, isTrue);
    expect(r.$2, 'Запущено: Ангел-хранитель · 30 с');
    expect(rig.events, isEmpty, reason: 'проверка не пишет в историю подарков');
    await rig.close();
  });

  test('без мира неба команда объясняет, что открыть', () async {
    final rig = await SkyRig.start();
    final r = await rig.engine.command('start');
    expect(r.$1, isFalse);
    expect(r.$2, contains('Мод Dirronlive Bridge не подключён'));
    await rig.close();
  });

  test('оверлей «Небесный разлом»: сектор, кольца, время, ошибки, эффекты', () async {
    final rig = await SkyRig.start();
    final empty = buildOverlayModel(OverlayKind.skyRift, rig.container.read(overlayInputsProvider));
    expect(empty['main'], 'Ждём мир DirronSky');
    await rig.connectSky();
    final m = buildOverlayModel(OverlayKind.skyRift, rig.container.read(overlayInputsProvider));
    expect(m['kind'], 'sky');
    expect(m['main'], 'Сектор 3 / 6');
    expect(m['sub'], 'Кольцо 2 / 7');
    expect(m['errors'], 0);
    expect((m['effects']! as List).single, containsPair('title', 'Боковой ветер'));
    expect(m['runningSince'], isNotNull);
    await rig.container.read(overlaySettingsProvider.notifier).setTestMode(true);
    final t = buildOverlayModel(OverlayKind.skyRift, rig.container.read(overlayInputsProvider));
    expect(t['test'], isTrue);
    expect(t['errors'], 2);
    await rig.close();
  });

  for (final size in const [Size(1920, 1080), Size(1024, 700)]) {
    testWidgets('${size.width.toInt()}×${size.height.toInt()}: экран режима — 10 карточек и управление',
        (tester) async {
      final container = await pumpDirronlive(
        tester,
        MemoryJsonStore(),
        size: size,
        overrides: [
          fakeLink(MinecraftLinkState(
            phase: LinkPhase.worldReady,
            skyMode: true,
            sky: SkyInfo.fromJson(_skyStatus(phase: 'idle')),
          )),
        ],
      );
      await openSection(tester, 'modes');
      final open = find.byKey(const ValueKey('open-sky_rift'));
      await tester.ensureVisible(open);
      await tester.tap(open);
      await tester.pumpAndSettle();
      expectNoFlutterError(tester, 'экран неба');
      for (final a in skyActions) {
        expect(find.byKey(Key('sky-card-${a.id}')), findsOneWidget, reason: a.id);
        expect(find.byKey(Key('sky-test-${a.id}')), findsOneWidget, reason: a.id);
        expect(find.byKey(Key('sky-enabled-${a.id}')), findsOneWidget, reason: a.id);
      }
      expect(find.byKey(const Key('sky-cmd-start')), findsOneWidget);
      expect(find.byKey(const Key('sky-cmd-pause')), findsOneWidget);
      expect(find.text('3 / 6'), findsOneWidget);

      // Профиль «Красота» сохраняется.
      final beauty = find.byKey(const Key('sky-profile-beauty'));
      await tester.ensureVisible(beauty);
      await tester.tap(beauty);
      await tester.pumpAndSettle();
      expect(container.read(skySettingsProvider).profile, 'beauty');

      // Выключить карточку.
      final sw = find.byKey(const Key('sky-enabled-storm'));
      await tester.ensureVisible(sw);
      await tester.tap(sw);
      await tester.pumpAndSettle();
      expect(container.read(skySettingsProvider).card('storm').enabled, isFalse);
      expectNoFlutterError(tester, 'после изменений');

      final back = find.byKey(const Key('sky-back'));
      await tester.ensureVisible(back);
      await tester.tap(back);
      await tester.pumpAndSettle();
      expect(find.byKey(const ValueKey('mode-sky_rift')), findsOneWidget);
      await closeDirronlive(tester, container);
    });
  }
}
