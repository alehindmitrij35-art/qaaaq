// Подключение к TikTok LIVE и подарки из эфира — на подменном коннекторе
// (реальный эфир в тестах недоступен) и с «поддельным модом» по настоящему
// WebSocket. Без testWidgets: таймеры и сеть настоящие.

import 'package:dirronlive/bootstrap.dart';
import 'package:dirronlive/core/events/delivery_status.dart';
import 'package:dirronlive/core/events/event_source.dart';
import 'package:dirronlive/core/events/gift_event.dart';
import 'package:dirronlive/core/initial_data.dart';
import 'package:dirronlive/features/events/event_log.dart';
import 'package:dirronlive/features/events/test_gift.dart';
import 'package:dirronlive/features/minecraft/minecraft_link.dart';
import 'package:dirronlive/features/parkour/gift_catalog.dart';
import 'package:dirronlive/features/settings/settings_controller.dart';
import 'package:dirronlive/features/tiktok/gift_aggregator.dart';
import 'package:dirronlive/features/tiktok/tiktok_controller.dart';
import 'package:dirronlive/features/tiktok/tiktok_state.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/fake_mod.dart';
import 'support/fake_tiktok.dart';
import 'support/memory_store.dart';

class TikTokHarness {
  TikTokHarness._(this.container, this.backend, this.store);

  static Future<TikTokHarness> start({String nickname = 'dirron'}) async {
    final store = MemoryJsonStore();
    final backend = FakeTikTokBackend();
    final container = createAppContainer(
      await loadInitialData(store),
      overrides: [
        tiktokBackendProvider.overrideWithValue(backend),
        tiktokConfigProvider.overrideWithValue(const TikTokConfig(
          // Паузы заметно длиннее ожидания в тестах (settle = 60 мс), чтобы
          // успеть увидеть статус «Переподключение через …» до попытки.
          backoff: [
            Duration(milliseconds: 300),
            Duration(milliseconds: 600),
            Duration(milliseconds: 900),
          ],
          finalizeStreakAfter: Duration(milliseconds: 400),
        )),
        minecraftLinkConfigProvider.overrideWithValue(const MinecraftLinkConfig(
          port: 0,
          ackTimeout: Duration(milliseconds: 400),
        )),
      ],
    );
    await container
        .read(settingsProvider.notifier)
        .saveTikTok(nickname: nickname, apiKey: '');
    return TikTokHarness._(container, backend, store);
  }

  final ProviderContainer container;
  final FakeTikTokBackend backend;
  final MemoryJsonStore store;

  TikTokController get tiktok => container.read(tiktokProvider.notifier);
  TikTokState get state => container.read(tiktokProvider);
  List<GiftEvent> get events => container.read(eventLogProvider).events;

  Future<FakeMod> openWorld() async {
    final link = container.read(minecraftLinkProvider.notifier);
    await link.start();
    final mod = await FakeMod.connect(container.read(minecraftLinkProvider).port!);
    await waitFor(() => container.read(minecraftLinkProvider).modConnected);
    mod.hello(worldReady: true);
    await waitFor(() => container.read(minecraftLinkProvider).worldReady);
    return mod;
  }

  Future<void> settle() => Future<void>.delayed(const Duration(milliseconds: 60));

  Future<void> dispose() async {
    await tiktok.disconnect();
    await container.read(minecraftLinkProvider.notifier).stop();
    await container.read(eventLogProvider.notifier).flush();
    container.dispose();
  }
}

void main() {
  test('ник с @ и без: подключение к тому же аккаунту', () async {
    final h = await TikTokHarness.start(nickname: '  @Dirron_Live ');
    await h.tiktok.connect();
    expect(h.backend.last.uniqueId, 'Dirron_Live');
    expect(h.state.phase, TikTokPhase.connecting);
    expect(h.state.label, 'Подключение…');
    await h.dispose();
  });

  test('«Подключено» только после подтверждения коннектора', () async {
    final h = await TikTokHarness.start();
    await h.tiktok.connect();
    await h.settle();
    expect(h.state.phase, TikTokPhase.connecting);

    h.backend.last.connected();
    await h.settle();
    expect(h.state.phase, TikTokPhase.connected);
    expect(h.state.label, 'Подключено');
    expect(h.state.uniqueId, 'dirron');
    await h.dispose();
  });

  test('эфир ещё не начался → «Эфир не найден», «Повторить» подключает',
      () async {
    final h = await TikTokHarness.start();
    await h.tiktok.connect();
    h.backend.last.status('offline', message: 'not live');
    await h.backend.last.exit();
    await h.settle();
    expect(h.state.phase, TikTokPhase.offline);
    expect(h.state.label, 'Эфир не найден');
    expect(h.state.canRetry, isTrue);

    // Без автоповтора: новых попыток нет.
    await Future<void>.delayed(const Duration(milliseconds: 300));
    expect(h.backend.sessions.length, 1);

    // Эфир запущен — «Повторить».
    await h.tiktok.connect();
    h.backend.last.connected();
    await h.settle();
    expect(h.backend.sessions.length, 2);
    expect(h.state.phase, TikTokPhase.connected);
    await h.dispose();
  });

  test('ошибки сети и сервиса показываются отдельно', () async {
    final h = await TikTokHarness.start();
    await h.tiktok.connect();
    h.backend.last.status('error', kind: 'network', message: 'Ошибка сети: ENOTFOUND');
    await h.backend.last.exit();
    await h.settle();
    expect(h.state.phase, TikTokPhase.networkError);
    expect(h.state.label, 'Ошибка сети');
    expect(h.state.message, contains('ENOTFOUND'));

    await h.tiktok.connect();
    h.backend.last.status('error', kind: 'service', message: 'лимит Euler Stream');
    await h.backend.last.exit();
    await h.settle();
    expect(h.state.phase, TikTokPhase.serviceError);
    expect(h.state.label, 'Ошибка сервиса');
    await h.dispose();
  });

  test('обрыв после подключения → переподключение с растущей паузой',
      () async {
    final h = await TikTokHarness.start();
    await h.tiktok.connect();
    h.backend.last.connected();
    await h.settle();

    h.backend.last.status('disconnected');
    await h.backend.last.exit();
    await h.settle();
    expect(h.state.phase, TikTokPhase.reconnecting);
    expect(h.state.retryIn, const Duration(milliseconds: 300));

    await waitFor(() => h.backend.sessions.length == 2, reason: 'попытка 1');
    await h.backend.last.exit(); // снова неудачно
    await h.settle();
    expect(h.state.retryIn, const Duration(milliseconds: 600), reason: 'пауза растёт');

    await waitFor(() => h.backend.sessions.length == 3, reason: 'попытка 2');
    h.backend.last.connected();
    await h.settle();
    expect(h.state.phase, TikTokPhase.connected);
    await h.dispose();
  });

  test('«Отключиться» прекращает приём и попытки', () async {
    final h = await TikTokHarness.start();
    await h.tiktok.connect();
    final session = h.backend.last;
    session.connected();
    await h.settle();
    session.status('disconnected');
    await session.exit();
    await h.settle();
    expect(h.state.phase, TikTokPhase.reconnecting);

    await h.tiktok.disconnect();
    expect(h.state.phase, TikTokPhase.off);
    await Future<void>.delayed(const Duration(milliseconds: 800));
    expect(h.backend.sessions.length, 1, reason: 'после отключения попыток нет');

    // Подарки из остановленной сессии не принимаются.
    session.gift(streakable: false);
    await h.settle();
    expect(h.events, isEmpty);
    await h.dispose();
  });

  test('конец эфира → «Эфир завершён», история сохранена', () async {
    final h = await TikTokHarness.start();
    await h.tiktok.connect();
    final session = h.backend.last;
    session.connected();
    session.gift(streakable: false, giftName: 'GG');
    session.status('ended');
    await session.exit();
    await h.settle();
    expect(h.state.phase, TikTokPhase.ended);
    expect(h.state.label, 'Эфир завершён');
    await h.container.read(eventLogProvider.notifier).flush();
    final saved = await loadInitialData(h.store);
    expect(saved.history.single.source, EventSource.tiktok);
    expect(saved.history.single.giftName, 'GG');
    await h.dispose();
  });

  test('одна роза при открытом мире: одна запись с ником, одно сообщение в игре',
      () async {
    final h = await TikTokHarness.start();
    final mod = await h.openWorld();
    await h.tiktok.connect();
    final session = h.backend.last..connected();
    // Серийный подарок даже одиночный приходит двумя событиями.
    session.gift(nickname: 'Alex', groupId: 'g1', repeatCount: 1);
    session.gift(nickname: 'Alex', groupId: 'g1', repeatCount: 1, repeatEnd: true);
    await waitFor(() => mod.gifts.length == 1);
    await h.settle();

    expect(h.events.length, 1);
    final record = h.events.single;
    expect(record.source, EventSource.tiktok);
    expect(record.source.label, 'TikTok LIVE');
    expect(record.viewerName, 'Alex');
    expect(record.giftName, 'Роза');
    expect(record.count, 1);
    expect(mod.gifts.single['viewerName'], 'Alex');
    expect(mod.gifts.single['count'], 1);

    mod.ack(mod.gifts.single['id']! as String);
    await waitFor(() => h.events.single.delivery == DeliveryStatus.delivered);
    await h.dispose();
  });

  test('серия из пяти роз 1…5: одна запись «Роза ×5», в игре одно сообщение',
      () async {
    final h = await TikTokHarness.start();
    final mod = await h.openWorld();
    await h.tiktok.connect();
    final session = h.backend.last..connected();
    for (var n = 1; n <= 5; n++) {
      session.gift(groupId: 'streak-5', repeatCount: n);
    }
    await h.settle();
    expect(h.events.length, 1);
    expect(h.events.single.giftText, 'Роза ×5');
    expect(mod.gifts, isEmpty, reason: 'серия ещё идёт');

    session.gift(groupId: 'streak-5', repeatCount: 5, repeatEnd: true);
    await waitFor(() => mod.gifts.length == 1);
    await Future<void>.delayed(const Duration(milliseconds: 200));
    expect(mod.gifts.length, 1);
    expect(mod.gifts.single['count'], 5);
    expect(h.events.length, 1);
    expect(h.events.single.comboActive, isFalse);
    await h.dispose();
  });

  test('комбо без пометки «серийный»: ×15, ×16, ×17 с одним groupId — одна запись ×17, а не 48', () async {
    final h = await TikTokHarness.start();
    final mod = await h.openWorld();
    await h.tiktok.connect();
    final session = h.backend.last..connected();
    for (final n in [15, 16, 17]) {
      session.gift(streakable: false, groupId: 'combo-x', repeatCount: n);
    }
    await h.settle();
    expect(h.events.length, 1, reason: 'шаги одной серии');
    expect(h.events.single.giftText, 'Роза ×17');
    session.gift(streakable: false, groupId: 'combo-x', repeatCount: 17, repeatEnd: true);
    await waitFor(() => mod.gifts.length == 1);
    expect(mod.gifts.single['count'], 17, reason: 'итог серии, а не 15 + 16 + 17 = 48');
    // Один подарок двумя сообщениями («идёт» и «закончилось», оба ×1) — один раз.
    session.gift(streakable: false, groupId: 'pair', giftName: 'Lion', giftId: '6064', repeatCount: 1);
    session.gift(
        streakable: false, groupId: 'pair', giftName: 'Lion', giftId: '6064', repeatCount: 1, repeatEnd: true);
    await waitFor(() => mod.gifts.length == 2);
    expect(mod.gifts.last['count'], 1, reason: 'два сообщения одного подарка — не 2');
    expect(h.events.where((e) => e.giftId == '6064'), hasLength(1));
    // Новое комбо того же зрителя — новая запись.
    session.gift(streakable: false, groupId: 'combo-y', repeatCount: 1, repeatEnd: true);
    await waitFor(() => mod.gifts.length == 3);
    expect(mod.gifts.last['count'], 1);
    await h.dispose();
  });

  test('повторная доставка того же события и серии не дублирует', () async {
    final h = await TikTokHarness.start();
    final mod = await h.openWorld();
    await h.tiktok.connect();
    final session = h.backend.last..connected();
    session.gift(streakable: false, msgId: 'same', giftName: 'Lion');
    session.gift(streakable: false, msgId: 'same', giftName: 'Lion');
    session.gift(groupId: 'g', repeatCount: 3, repeatEnd: true, msgId: 'end');
    session.gift(groupId: 'g', repeatCount: 3, repeatEnd: true, msgId: 'end');
    session.gift(groupId: 'g', repeatCount: 3, repeatEnd: true); // новый msgId, та же серия
    await waitFor(() => mod.gifts.length == 2);
    await Future<void>.delayed(const Duration(milliseconds: 200));
    expect(h.events.length, 2);
    expect(mod.gifts.length, 2);
    await h.dispose();
  });

  test('два самостоятельных подарка одного зрителя — две записи', () async {
    final h = await TikTokHarness.start();
    await h.tiktok.connect();
    final session = h.backend.last..connected();
    session.gift(groupId: 'first', repeatCount: 2, repeatEnd: true);
    session.gift(groupId: 'second', repeatCount: 2, repeatEnd: true);
    session.gift(streakable: false, giftName: 'Lion');
    session.gift(streakable: false, giftName: 'Lion');
    await h.settle();
    expect(h.events.length, 4);
    expect(h.events.where((e) => e.giftName == 'Лев').length, 2);
    await h.dispose();
  });

  test('Minecraft закрыт: подарки идут в журнал «Только в журнале»', () async {
    final h = await TikTokHarness.start();
    await h.tiktok.connect();
    final session = h.backend.last..connected();
    session.gift(streakable: false, giftName: 'Galaxy');
    await h.settle();
    expect(h.events.single.delivery, DeliveryStatus.logOnly);
    expect(h.events.single.giftName, 'Галактика');
    await h.dispose();
  });

  test('серия без конца (обрыв) завершается сама и уходит один раз', () async {
    final h = await TikTokHarness.start();
    final mod = await h.openWorld();
    await h.tiktok.connect();
    final session = h.backend.last..connected();
    session.gift(groupId: 'cut', repeatCount: 1);
    session.gift(groupId: 'cut', repeatCount: 2);
    await h.settle();
    expect(mod.gifts, isEmpty);
    await waitFor(() => mod.gifts.length == 1, reason: 'автозавершение серии');
    expect(mod.gifts.single['count'], 2);
    expect(h.events.single.comboActive, isFalse);
    await h.dispose();
  });

  test('«Тестовый подарок» работает без эфира и помечен «Тест»', () async {
    final h = await TikTokHarness.start();
    expect(h.state.phase, TikTokPhase.off);
    h.container.read(testGiftSenderProvider).send();
    await h.settle();
    expect(h.events.single.source.label, 'Тест');
    await h.dispose();
  });

  test('агрегатор без groupId: серия по зрителю и подарку', () async {
    final published = <GiftEvent>[];
    final aggregator = TikTokGiftAggregator(
      publish: published.add,
      finalizeAfter: const Duration(seconds: 10),
    );
    for (var n = 1; n <= 3; n++) {
      aggregator.add({
        'msgId': 'x$n', 'streakable': true, 'repeatCount': n,
        'repeatEnd': n == 3, 'userId': 'u', 'giftId': 'r', 'giftName': 'Rose',
        'nickname': 'Alex',
      });
    }
    final combos = published.map((e) => e.comboId).toSet();
    expect(combos.length, 1);
    expect(published.last.count, 3);
    expect(published.last.comboActive, isFalse);
    expect(aggregator.openStreaks, 0);
    aggregator.dispose();
  });

  test('каталог подарков берётся у подключения к эфиру: сам и по «Обновить каталог»', () async {
    final h = await TikTokHarness.start();
    await h.tiktok.connect();
    final session = h.backend.last;
    session.connected();
    await h.settle();

    // Сразу после подключения коннектор прислал каталог — он сохранён.
    session.catalog([
      {'id': '5655', 'name': 'Rose', 'diamonds': 1, 'image': 'https://example.test/rose.png'},
      {'id': '5487', 'name': 'Finger Heart', 'diamonds': 5},
    ], where: 'connect');
    await h.settle();
    final catalog = h.container.read(giftCatalogProvider);
    expect(catalog.catalog.gifts.map((g) => g.id), ['5655', '5487']);
    expect(catalog.catalog.byId('5655')!.imageUrl, 'https://example.test/rose.png');
    expect(catalog.report?.allAvailable, isTrue);
    expect(h.store.files.containsKey(GiftCatalogRepository.fileName), isTrue);

    // «Обновить каталог» во время эфира идёт через то же подключение.
    final pending = h.container.read(giftCatalogProvider.notifier).refreshAndCheck();
    await h.settle();
    expect(session.giftRequests, 1);
    session.catalog([
      {'id': '5655', 'name': 'Rose', 'diamonds': 1},
      {'id': '5487', 'name': 'Finger Heart', 'diamonds': 5},
      {'id': '6064', 'name': 'Lion', 'diamonds': 29999},
    ]);
    final report = await pending;
    expect(report.fetched, isTrue);
    expect(report.connectorCount, 3);
    expect(report.added, ['Лев (29999 мон.)'], reason: 'ID подарка в отчёте не показывается');
    expect(report.allAvailable, isTrue);

    // Ошибка коннектора: причина со всеми попытками, прежний каталог открыт.
    final failing = h.container.read(giftCatalogProvider.notifier).refreshAndCheck();
    await h.settle();
    session.catalogError('Gift list request failed: 403');
    final failed = await failing;
    expect(failed.allAvailable, isFalse);
    expect(failed.error, contains('403'));
    expect(failed.error, contains('Попытки'));
    expect(h.container.read(giftCatalogProvider).catalog.gifts, hasLength(3));
    await h.dispose();
  });
}
