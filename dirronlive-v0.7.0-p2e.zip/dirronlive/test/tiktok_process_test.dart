// Настоящий запуск коннектора отдельным процессом Node.js — так, как это
// делает программа. Вместо библиотеки tiktok-live-connector подставлена
// поддельная (tiktok_connector/test/fake-lib.mjs), поэтому сеть не нужна.
// Если Node.js на машине нет, тест пропускается.

import 'dart:io';

import 'package:dirronlive/bootstrap.dart';
import 'package:dirronlive/core/events/event_source.dart';
import 'package:dirronlive/core/initial_data.dart';
import 'package:dirronlive/features/events/event_log.dart';
import 'package:dirronlive/features/settings/settings_controller.dart';
import 'package:dirronlive/features/tiktok/connector_backend.dart';
import 'package:dirronlive/features/tiktok/tiktok_controller.dart';
import 'package:dirronlive/features/tiktok/tiktok_state.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/fake_mod.dart';
import 'support/memory_store.dart';

String? nodeMissing() {
  try {
    final result = Process.runSync('node', ['--version']);
    if (result.exitCode != 0) return 'node не запускается';
    final major = int.tryParse(
        '${result.stdout}'.trim().replaceFirst('v', '').split('.').first);
    if (major == null || major < 20) return 'нужен Node.js 20+';
    return null;
  } on ProcessException {
    return 'Node.js не установлен';
  }
}

NodeConnectorBackend backendFor(String scenario) {
  final dir = '${Directory.current.path}${Platform.pathSeparator}tiktok_connector';
  final sep = Platform.pathSeparator;
  return NodeConnectorBackend(
    location: ConnectorLocation(
      node: 'node',
      script: '$dir${sep}connector.mjs',
      workingDirectory: dir,
    ),
    environment: {
      'DIRRONLIVE_TIKTOK_LIB':
          Uri.file('$dir${sep}test${sep}fake-lib.mjs').toString(),
      'DIRRONLIVE_FAKE_SCENARIO': scenario,
      // Общий список TikTok «недоступен»: проверяем путь через подключение.
      'DIRRONLIVE_GIFT_LIST_URL': 'data:application/json,{"status_code":5}',
    },
  );
}

void main() {
  final skip = nodeMissing();

  test('процесс коннектора: строки JSON → сообщения', () async {
    final session = backendFor('gifts').start(uniqueId: 'dirron');
    final messages = await session.messages.toList();
    expect(messages.first['status'], 'connecting');
    expect(messages.any((m) => m['status'] == 'connected'), isTrue);
    expect(messages.where((m) => m['type'] == 'gift').length, 7);
    expect(messages.any((m) => m['status'] == 'ended'), isTrue);
    expect(messages.last['type'], 'exit');
  }, skip: skip);

  test('эфир не найден приходит из процесса', () async {
    final session = backendFor('offline').start(uniqueId: 'dirron');
    final messages = await session.messages.toList();
    expect(messages.any((m) => m['status'] == 'offline'), isTrue);
  }, skip: skip);

  test('программа целиком: процесс → серия и подарок в журнале → конец эфира',
      () async {
    final store = MemoryJsonStore();
    final container = createAppContainer(
      await loadInitialData(store),
      overrides: [tiktokBackendProvider.overrideWithValue(backendFor('gifts'))],
    );
    await container
        .read(settingsProvider.notifier)
        .saveTikTok(nickname: '@dirron', apiKey: '');
    await container.read(tiktokProvider.notifier).connect();
    await waitFor(
        () => container.read(tiktokProvider).phase == TikTokPhase.ended,
        reason: 'эфир завершён');

    final events = container.read(eventLogProvider).events;
    expect(events.length, 2, reason: 'серия 1…5 и одиночный подарок');
    final streak = events.firstWhere((e) => e.isCombo);
    expect(streak.giftText, 'Роза ×5');
    expect(streak.viewerName, 'Alex');
    expect(streak.source, EventSource.tiktok);
    expect(streak.comboActive, isFalse);
    await container.read(eventLogProvider.notifier).flush();
    container.dispose();
  }, skip: skip);

  test('«Отключиться» завершает процесс коннектора', () async {
    final session = backendFor('idle').start(uniqueId: 'dirron');
    final messages = <Map<String, Object?>>[];
    final done = session.messages.forEach(messages.add);
    await waitFor(() => messages.any((m) => m['status'] == 'connected'));
    await session.stop();
    await done.timeout(const Duration(seconds: 5));
    expect(messages.last['type'], 'exit');
  }, skip: skip);
}
