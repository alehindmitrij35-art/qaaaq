// Подключение к TikTok LIVE реализовано в lib/features/tiktok/
// (коннектор tiktok_connector/connector.mjs, контроллер tiktok_controller.dart).
// Файл оставлен пустым, чтобы при загрузке поверх старой версии заменить
// прежний контракт. Его можно удалить.
