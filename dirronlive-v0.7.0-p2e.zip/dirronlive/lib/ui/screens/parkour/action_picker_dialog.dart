import 'package:flutter/material.dart';

import '../../../features/parkour/action_catalog.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_theme.dart';
import 'action_look.dart';

/// Окно «Добавить действие»: все 24 действия сеткой с крупными значками.
class ActionPickerDialog extends StatefulWidget {
  const ActionPickerDialog({super.key});

  static Future<ParkourAction?> show(BuildContext context) => showDialog<ParkourAction>(
        context: context,
        builder: (_) => const ActionPickerDialog(),
      );

  @override
  State<ActionPickerDialog> createState() => _ActionPickerDialogState();
}

class _ActionPickerDialogState extends State<ActionPickerDialog> {
  final _search = TextEditingController();

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final q = _search.text.trim().toLowerCase();
    final shown = parkourActions
        .where((a) => q.isEmpty || a.title.toLowerCase().contains(q) || a.hint.toLowerCase().contains(q))
        .toList();
    final size = MediaQuery.sizeOf(context);
    return Dialog(
      key: const Key('action-picker'),
      backgroundColor: plum,
      insetPadding: const EdgeInsets.all(24),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: 1100, maxHeight: size.height - 48),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 20, 24, 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  const Expanded(
                    child: Text('Добавить действие',
                        style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: AppColors.text)),
                  ),
                  IconButton(
                    key: const Key('action-picker-close'),
                    onPressed: () => Navigator.of(context).pop(),
                    icon: const Icon(Icons.close_rounded, color: AppColors.textMuted),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Wrap(
                spacing: 14,
                runSpacing: 6,
                children: [
                  for (final c in ActionCategory.values)
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 10,
                          height: 10,
                          decoration: BoxDecoration(color: categoryColor(c), shape: BoxShape.circle),
                        ),
                        const SizedBox(width: 6),
                        Text(c.label, style: const TextStyle(fontSize: 13, color: AppColors.textMuted)),
                      ],
                    ),
                ],
              ),
              const SizedBox(height: 12),
              TextField(
                key: const Key('action-picker-search'),
                controller: _search,
                autofocus: true,
                onChanged: (_) => setState(() {}),
                style: const TextStyle(fontSize: 15, color: AppColors.text),
                decoration: appInputDecoration(
                  label: 'Поиск действия',
                  hint: 'толчок, комната, щит…',
                  icon: Icons.search_rounded,
                ),
              ),
              const SizedBox(height: 14),
              Flexible(
                child: shown.isEmpty
                    ? const Center(
                        child: Text('Ничего не найдено', style: TextStyle(color: AppColors.textFaint)))
                    : GridView.builder(
                        shrinkWrap: true,
                        gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                          maxCrossAxisExtent: 250,
                          mainAxisExtent: 150,
                          crossAxisSpacing: 12,
                          mainAxisSpacing: 12,
                        ),
                        itemCount: shown.length,
                        itemBuilder: (context, i) => _ActionTile(action: shown[i]),
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ActionTile extends StatelessWidget {
  const _ActionTile({required this.action});

  final ParkourAction action;

  @override
  Widget build(BuildContext context) {
    final color = categoryColor(action.category);
    final superPush = action.id == 'super_push';
    return Material(
      color: superPush ? const Color(0xFF4A1F3A) : plumHigh,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        key: Key('pick-action-${action.id}'),
        borderRadius: BorderRadius.circular(16),
        onTap: () => Navigator.of(context).pop(action),
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: color.withAlpha(superPush ? 220 : 90), width: superPush ? 2 : 1),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ActionBadge(action: action, size: 48),
                  const Spacer(),
                  Text(action.category.label,
                      style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: color)),
                ],
              ),
              const SizedBox(height: 10),
              Text(
                action.title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: superPush ? 14 : 15,
                  fontWeight: FontWeight.w900,
                  color: AppColors.text,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                action.hint,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 12, height: 1.3, color: AppColors.textMuted),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
