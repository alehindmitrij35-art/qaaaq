import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/providers.dart';
import '../../../features/minecraft/minecraft_link.dart';
import '../../../features/modes/modes_catalog.dart';
import '../../../features/navigation/app_section.dart';
import '../../../features/parkour/parkour_engine.dart';
import '../../../features/parkour/parkour_rules.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_theme.dart';
import '../../widgets/common.dart';
import 'rules_tab.dart';

enum ParkourTab {
  actions('Действия за подарки', Icons.bolt_rounded),
  about('О карте', Icons.map_rounded);

  const ParkourTab(this.label, this.icon);

  final String label;
  final IconData icon;
}

/// Режимы → «Dirron Parkour: 100 комнат».
class ParkourScreen extends ConsumerStatefulWidget {
  const ParkourScreen({super.key, this.second = false});

  /// Ячейка «Dirron Parkour 2»: те же действия и подарки, другой мир.
  final bool second;

  @override
  ConsumerState<ParkourScreen> createState() => _ParkourScreenState();
}

class _ParkourScreenState extends ConsumerState<ParkourScreen> {
  ParkourTab _tab = ParkourTab.actions;

  @override
  Widget build(BuildContext context) {
    final rules = ref.watch(parkourRulesProvider);
    return SingleChildScrollView(
      key: const Key('parkour-scroll'),
      padding: const EdgeInsets.fromLTRB(32, 20, 32, 32),
      child: Align(
        alignment: Alignment.topLeft,
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 1280),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Align(
                alignment: Alignment.centerLeft,
                child: TextButton.icon(
                  key: const Key('parkour-back'),
                  onPressed: () => ref.read(openModeProvider.notifier).open(null),
                  icon: const Icon(Icons.arrow_back_rounded, size: 18),
                  label: const Text('Режимы'),
                ),
              ),
              const SizedBox(height: 6),
              Wrap(
                spacing: 16,
                runSpacing: 12,
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  PageHeader(
                    title: widget.second ? 'Dirron Parkour 2: 100 уровней' : 'Dirron Parkour: 100 комнат',
                    subtitle: widget.second
                        ? 'Мир DirronParkour2 · действия и подарки общие с первым паркуром'
                        : 'Выбери подарок в карточке и проверь действие в игре до эфира',
                  ),
                  _ModeSwitch(active: rules.modeActive),
                ],
              ),
              const SizedBox(height: 18),
              const _GameStatusCard(),
              const SizedBox(height: 18),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final tab in ParkourTab.values)
                    ChoiceChip(
                      key: Key('parkour-tab-${tab.name}'),
                      selected: _tab == tab,
                      onSelected: (_) => setState(() => _tab = tab),
                      avatar: Icon(tab.icon, size: 18,
                          color: _tab == tab ? AppColors.onAccent : AppColors.textMuted),
                      label: Text(tab.label),
                      showCheckmark: false,
                      selectedColor: AppColors.accent,
                      labelStyle: TextStyle(
                        fontWeight: FontWeight.w700,
                        color: _tab == tab ? AppColors.onAccent : AppColors.text,
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 16),
              if (rules.saveError != null) ...[
                ErrorBanner(message: rules.saveError!),
                const SizedBox(height: 12),
              ],
              switch (_tab) {
                ParkourTab.actions => const RulesTab(),
                ParkourTab.about => const _AboutTab(),
              },
            ],
          ),
        ),
      ),
    );
  }
}

class _ModeSwitch extends ConsumerWidget {
  const _ModeSwitch({required this.active});

  final bool active;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Panel(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      borderColor: active ? AppColors.success.withAlpha(120) : null,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            active ? 'Режим активен' : 'Режим выключен',
            style: TextStyle(
              fontWeight: FontWeight.w700,
              color: active ? AppColors.success : AppColors.textMuted,
            ),
          ),
          const SizedBox(width: 10),
          Switch(
            key: const Key('parkour-mode-switch'),
            value: active,
            onChanged: (value) async {
              final error =
                  await ref.read(parkourRulesProvider.notifier).setModeActive(value);
              if (error != null) ref.read(noticeServiceProvider).error(error);
            },
          ),
        ],
      ),
    );
  }
}

/// Что сейчас в игре и переход в нужную комнату для проверки.
class _GameStatusCard extends ConsumerStatefulWidget {
  const _GameStatusCard();

  @override
  ConsumerState<_GameStatusCard> createState() => _GameStatusCardState();
}

class _GameStatusCardState extends ConsumerState<_GameStatusCard> {
  final _room = TextEditingController(text: '12');
  bool _busy = false;
  ActionOutcome? _result;

  @override
  void dispose() {
    _room.dispose();
    super.dispose();
  }

  Future<void> _go() async {
    final room = int.tryParse(_room.text.trim());
    if (room == null || room < 1 || room > 100) {
      setState(() => _result = const ActionOutcome(false, 'Номер комнаты — от 1 до 100'));
      return;
    }
    setState(() => _busy = true);
    final result = await ref.read(parkourEngineProvider).goToRoom(room);
    if (!mounted) return;
    setState(() {
      _busy = false;
      _result = result;
    });
  }

  @override
  Widget build(BuildContext context) {
    final link = ref.watch(minecraftLinkProvider);
    final blocker = link.parkourBlocker;
    final info = link.parkour;
    final seconds = info.seconds;
    final statusText = blocker ??
        'Мир DirronParkour открыт · комната ${info.room} из 100'
            '${info.finished ? ' · ПОБЕДА' : ''} · падений ${info.falls}'
            ' · время ${seconds ~/ 60}:${(seconds % 60).toString().padLeft(2, '0')}';
    return Panel(
      key: const Key('parkour-status'),
      padding: const EdgeInsets.all(16),
      borderColor: blocker == null ? AppColors.success.withAlpha(110) : null,
      child: Wrap(
        spacing: 16,
        runSpacing: 12,
        crossAxisAlignment: WrapCrossAlignment.center,
        children: [
          ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 560),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  blocker == null ? Icons.check_circle_rounded : Icons.info_outline_rounded,
                  color: blocker == null ? AppColors.success : AppColors.warning,
                  size: 20,
                ),
                const SizedBox(width: 10),
                Flexible(
                  child: Text(
                    statusText,
                    key: const Key('parkour-status-text'),
                    style: const TextStyle(fontSize: 14, color: AppColors.text, height: 1.35),
                  ),
                ),
              ],
            ),
          ),
          if (blocker != null && !link.enabled)
            OutlinedButton.icon(
              key: const Key('parkour-open-settings'),
              onPressed: () => ref
                  .read(currentSectionProvider.notifier)
                  .openSettings(SettingsSection.minecraft),
              icon: const Icon(Icons.settings_rounded, size: 18),
              label: const Text('Включить связь'),
            ),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(
                width: 140,
                child: TextField(
                  key: const Key('parkour-room-field'),
                  controller: _room,
                  keyboardType: TextInputType.number,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  onSubmitted: (_) => _go(),
                  style: const TextStyle(fontSize: 15, color: AppColors.text),
                  decoration: appInputDecoration(label: 'Комната'),
                ),
              ),
              const SizedBox(width: 10),
              FilledButton.icon(
                key: const Key('parkour-goto'),
                onPressed: _busy || blocker != null ? null : _go,
                icon: const Icon(Icons.login_rounded, size: 18),
                label: const Text('Перейти'),
              ),
            ],
          ),
          if (_result != null)
            Text(
              _result!.text,
              key: const Key('parkour-goto-result'),
              style: TextStyle(
                fontSize: 13,
                color: _result!.ok ? AppColors.success : AppColors.danger,
              ),
            ),
        ],
      ),
    );
  }
}

class _AboutTab extends StatelessWidget {
  const _AboutTab();

  @override
  Widget build(BuildContext context) {
    const lines = [
      ('Карта', '100 комнат в пустом мире DirronParkour, 10 тем по 10 комнат: неон, коралловый риф, '
          'медовые соты, ледяные арки, слаймовая фабрика, малиновый сад, кузница, аметистовая '
          'спираль, карнавал и арена. Комната 100 — логотип Dirron, глаза загораются зелёным после победы.'),
      ('Как проходить', 'Встал на золотую финишную площадку — откроется следующая комната. Упал — '
          'вернёшься на чекпоинт. Урона от падения нет, всегда день, мобов нет.'),
      ('Уровень на экране', 'Сверху по центру — «УРОВЕНЬ 37 / 100». Номер меняется при прохождении, '
          'откате и переносе подарком; после финиша комнаты 100 — «Паркур пройден!».'),
      ('Сложность', 'Первые комнаты знакомят с механиками. В середине — точные приземления на блок, '
          'прыжки за угол и цепочки. В конце — подъёмы-башни, разгон по льду с прыжком через 4 блока и '
          'рискованные срезки по красным столбикам (основной маршрут всегда проходим).'),
      ('Команды в игре', '/parkour room 12 — перейти в комнату, /parkour stats — комната, падения, '
          'время, /parkour reset — начать заново, /parkour action room_back — проверить действие без программы.'),
      ('Установка', 'Fabric Loader 1.21.1, файл DirronliveBridge-2.3.0.jar в папку mods, папку '
          'DirronParkour в папку saves. Fabric API ставить не нужно.'),
    ];
    return Panel(
      key: const Key('parkour-about'),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          for (final (title, text) in lines) ...[
            Text(title,
                style: const TextStyle(
                    fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.text)),
            const SizedBox(height: 4),
            Text(text,
                style: const TextStyle(fontSize: 14, height: 1.45, color: AppColors.textMuted)),
            const SizedBox(height: 14),
          ],
        ],
      ),
    );
  }
}
