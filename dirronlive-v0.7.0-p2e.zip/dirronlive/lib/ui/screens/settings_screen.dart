import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/providers.dart';
import '../../features/connections/connections.dart';
import '../../features/events/event_history_repository.dart';
import '../../features/minecraft/link_state.dart';
import '../../features/minecraft/minecraft_link.dart';
import '../../features/navigation/app_section.dart';
import '../../features/settings/settings_controller.dart';
import '../../features/settings/settings_repository.dart';
import '../../features/tiktok/tiktok_controller.dart';
import '../theme/app_colors.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';

/// Настройки → Подключения: сначала TikTok LIVE, затем Minecraft.
/// При переходе из полосы состояния экран прокручивается к нужной
/// секции и ненадолго подсвечивает её.
class SettingsScreen extends ConsumerStatefulWidget {
  const SettingsScreen({super.key});

  static const nicknameFieldKey = Key('nickname-field');
  static const saveButtonKey = Key('save-nickname');
  static const tiktokSectionKey = Key('settings-tiktok');
  static const minecraftSectionKey = Key('settings-minecraft');
  static const linkToggleKey = Key('link-toggle');
  static const tiktokConnectKey = Key('tiktok-connect');
  static const tiktokDisconnectKey = Key('tiktok-disconnect');
  static const linkRetryKey = Key('link-retry');

  @override
  ConsumerState<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends ConsumerState<SettingsScreen> {
  late final TextEditingController _nickname;
  late final TextEditingController _eulerKey;
  bool _connectingTikTok = false;
  final ScrollController _scroll = ScrollController();
  final GlobalKey _tiktokAnchor = GlobalKey();
  final GlobalKey _minecraftAnchor = GlobalKey();
  bool _savingNickname = false;
  bool _switchingLink = false;
  SettingsSection? _highlighted;
  Timer? _highlightTimer;

  @override
  void initState() {
    super.initState();
    _nickname = TextEditingController(
      text: ref.read(settingsProvider).tiktokNickname,
    );
    _eulerKey = TextEditingController(
      text: ref.read(settingsProvider).eulerApiKey,
    );
    final focus = ref.read(settingsFocusProvider);
    if (focus != null) {
      WidgetsBinding.instance
          .addPostFrameCallback((_) => _focusSection(focus.section));
    }
  }

  @override
  void dispose() {
    _highlightTimer?.cancel();
    _nickname.dispose();
    _eulerKey.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _focusSection(SettingsSection section) async {
    if (!mounted) return;
    ref.read(settingsFocusProvider.notifier).clear();
    setState(() => _highlighted = section);
    _highlightTimer?.cancel();
    _highlightTimer = Timer(const Duration(milliseconds: 1800), () {
      if (mounted) setState(() => _highlighted = null);
    });
    final anchor =
        section == SettingsSection.tiktok ? _tiktokAnchor : _minecraftAnchor;
    final target = anchor.currentContext;
    if (target == null) return;
    await Scrollable.ensureVisible(
      target,
      duration: const Duration(milliseconds: 350),
      curve: Curves.easeOutCubic,
      alignment: 0.02,
    );
  }

  Future<void> _saveNickname() async {
    if (_savingNickname) return;
    setState(() => _savingNickname = true);
    final error =
        await ref.read(settingsProvider.notifier).saveNickname(_nickname.text);
    if (!mounted) return;
    setState(() => _savingNickname = false);

    final notices = ref.read(noticeServiceProvider);
    if (error != null) {
      notices.error(error);
      return;
    }
    final saved = ref.read(settingsProvider).tiktokNickname;
    _nickname.value = TextEditingValue(
      text: saved,
      selection: TextSelection.collapsed(offset: saved.length),
    );
    notices.info(saved.isEmpty ? 'Ник очищен' : 'Ник сохранён: @$saved');
  }

  /// «Подключиться»: сохраняет введённый ник (с @ или без) и подключается.
  Future<void> _connectTikTok() async {
    if (_connectingTikTok) return;
    setState(() => _connectingTikTok = true);
    final error = await ref
        .read(settingsProvider.notifier)
        .saveTikTok(nickname: _nickname.text, apiKey: _eulerKey.text);
    if (!mounted) return;
    setState(() => _connectingTikTok = false);
    if (error != null) {
      ref.read(noticeServiceProvider).error(error);
      return;
    }
    final saved = ref.read(settingsProvider).tiktokNickname;
    _nickname.value = TextEditingValue(
      text: saved,
      selection: TextSelection.collapsed(offset: saved.length),
    );
    await ref.read(tiktokProvider.notifier).connect();
  }

  Future<void> _setLink(bool enabled) async {
    if (_switchingLink) return;
    setState(() => _switchingLink = true);
    final error =
        await ref.read(minecraftLinkSwitchProvider).setEnabled(enabled);
    if (!mounted) return;
    setState(() => _switchingLink = false);
    if (error != null) ref.read(noticeServiceProvider).error(error);
  }

  @override
  Widget build(BuildContext context) {
    // Переход к секции, когда настройки уже открыты.
    ref.listen<SettingsFocus?>(settingsFocusProvider, (previous, next) {
      if (next != null) _focusSection(next.section);
    });

    final location = ref.watch(jsonStoreProvider).location;

    return SingleChildScrollView(
      controller: _scroll,
      padding: const EdgeInsets.fromLTRB(32, 24, 32, 32),
      child: Align(
        alignment: Alignment.topCenter,
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 900),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const PageHeader(
                title: 'Настройки',
                subtitle: 'Подключения к эфиру и игре, хранение данных',
              ),
              const SizedBox(height: 24),
              const Text(
                'Подключения',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                  color: AppColors.text,
                ),
              ),
              const SizedBox(height: 12),
              _Section(
                key: SettingsScreen.tiktokSectionKey,
                anchor: _tiktokAnchor,
                highlighted: _highlighted == SettingsSection.tiktok,
                icon: Icons.live_tv_rounded,
                title: 'TikTok LIVE',
                child: _buildTikTok(),
              ),
              const SizedBox(height: 16),
              _Section(
                key: SettingsScreen.minecraftSectionKey,
                anchor: _minecraftAnchor,
                highlighted: _highlighted == SettingsSection.minecraft,
                icon: Icons.videogame_asset_rounded,
                title: 'Minecraft',
                child: _buildMinecraft(),
              ),

              const SizedBox(height: 28),
              const Text(
                'Данные',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                  color: AppColors.text,
                ),
              ),
              const SizedBox(height: 12),
              Panel(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Где хранятся данные',
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        color: AppColors.text,
                      ),
                    ),
                    const SizedBox(height: 8),
                    SelectableText(
                      location,
                      key: const Key('data-location'),
                      style:
                          const TextStyle(fontSize: 14, color: AppColors.accent),
                    ),
                    const SizedBox(height: 6),
                    const Text(
                      'Файлы: ${SettingsRepository.fileName} (настройки) и '
                      '${EventHistoryRepository.fileName} (история событий).',
                      style:
                          TextStyle(fontSize: 13, color: AppColors.textMuted),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTikTok() {
    final tiktok = ref.watch(tiktokProvider);
    final busy = _savingNickname || _connectingTikTok;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        InfoRow(
          label: 'Состояние',
          trailing: StatusPill.tiktok(tiktok, key: const Key('tiktok-status')),
        ),
        if (tiktok.message != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Text(
              tiktok.message!,
              key: const Key('tiktok-message'),
              style: TextStyle(
                fontSize: 13,
                height: 1.4,
                color: tiktok.phase.color == AppColors.danger
                    ? AppColors.danger
                    : AppColors.textMuted,
              ),
            ),
          ),
        const SizedBox(height: 6),
        ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 520),
          child: TextField(
            key: SettingsScreen.nicknameFieldKey,
            controller: _nickname,
            enabled: !busy,
            onSubmitted: (_) => _saveNickname(),
            textInputAction: TextInputAction.done,
            style: const TextStyle(fontSize: 16, color: AppColors.text),
            decoration: appInputDecoration(
              label: 'Ник TikTok',
              hint: 'например, dirron',
              helper: 'Можно с @ или без. Пробелы по краям и один начальный @ '
                  'убираются при сохранении',
              icon: Icons.alternate_email_rounded,
            ),
          ),
        ),
        const SizedBox(height: 14),
        Wrap(
          spacing: 12,
          runSpacing: 12,
          children: [
            if (!tiktok.isActive)
              FilledButton.icon(
                key: SettingsScreen.tiktokConnectKey,
                onPressed: busy ? null : _connectTikTok,
                icon: const Icon(Icons.wifi_tethering_rounded, size: 18),
                label: Text(tiktok.canRetry ? 'Повторить' : 'Подключиться'),
              )
            else
              OutlinedButton.icon(
                key: SettingsScreen.tiktokDisconnectKey,
                onPressed: () => ref.read(tiktokProvider.notifier).disconnect(),
                icon: const Icon(Icons.link_off_rounded, size: 18),
                label: const Text('Отключиться'),
              ),
            OutlinedButton.icon(
              key: SettingsScreen.saveButtonKey,
              onPressed: busy ? null : _saveNickname,
              icon: const Icon(Icons.save_rounded, size: 18),
              label: const Text('Сохранить'),
            ),
          ],
        ),
        const SizedBox(height: 18),
        // Подложка Material нужна ExpansionTile внутри цветной карточки:
        // иначе Flutter предупреждает, что эффекты нажатия не видны.
        Material(
          type: MaterialType.transparency,
          child: ExpansionTile(
              key: const Key('tiktok-advanced'),
              tilePadding: EdgeInsets.zero,
              childrenPadding: const EdgeInsets.only(bottom: 8),
              iconColor: AppColors.accent,
              collapsedIconColor: AppColors.textMuted,
              title: const Text(
                'Ключ Euler Stream (необязательно)',
                style: TextStyle(fontSize: 14, color: AppColors.textMuted),
              ),
              children: [
                ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 520),
                  child: TextField(
                    key: const Key('euler-key-field'),
                    controller: _eulerKey,
                    obscureText: true,
                    enabled: !busy,
                    style: const TextStyle(fontSize: 15, color: AppColors.text),
                    decoration: appInputDecoration(
                      label: 'API-ключ Euler Stream',
                      hint: 'оставьте пустым для бесплатных общих лимитов',
                      helper: 'Бесплатный ключ: eulerstream.com → Dashboard. '
                          'Нужен, только если подключение упирается в лимит.',
                      icon: Icons.key_rounded,
                    ),
                  ),
                ),
              ],
            ),
        ),
        const SizedBox(height: 6),
        const Text(
          'Подарки приходят через коннектор TikTok-Live-Connector, который '
          'Dirronlive запускает и останавливает сам. Подключение возможно, '
          'когда эфир уже идёт.',
          style: TextStyle(fontSize: 13, height: 1.4, color: AppColors.textMuted),
        ),
      ],
    );
  }

  Widget _buildMinecraft() {
    final link = ref.watch(minecraftLinkProvider);
    final port = link.port ?? ref.watch(minecraftLinkConfigProvider).port;
    final busy = _switchingLink || link.phase == LinkPhase.starting;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        InfoRow(
          label: 'Состояние',
          trailing: StatusPill.link(link, key: const Key('link-status')),
        ),
        InfoRow(label: 'Адрес связи', value: '127.0.0.1:$port'),
        const InfoRow(
          label: 'Игра',
          value: '$minecraftTargetVersion · $minecraftWorldType',
        ),
        if (link.modConnected)
          InfoRow(
            label: 'Мод',
            value: 'Dirronlive Bridge ${link.modVersion ?? ''} · '
                'Minecraft ${link.minecraftVersion ?? '?'}',
          ),
        if (link.phase == LinkPhase.error) ...[
          const SizedBox(height: 8),
          ErrorBanner(
            message: '${link.errorTitle ?? 'Ошибка связи'}. '
                '${link.errorMessage ?? ''}',
          ),
          const SizedBox(height: 12),
        ],
        const SizedBox(height: 12),
        Wrap(
          spacing: 12,
          runSpacing: 12,
          children: [
            if (link.phase == LinkPhase.error)
              FilledButton.icon(
                key: SettingsScreen.linkRetryKey,
                onPressed: busy
                    ? null
                    : () => ref.read(minecraftLinkProvider.notifier).retry(),
                icon: const Icon(Icons.refresh_rounded, size: 18),
                label: const Text('Повторить'),
              ),
            if (!link.enabled)
              FilledButton.icon(
                key: SettingsScreen.linkToggleKey,
                onPressed: busy ? null : () => _setLink(true),
                icon: const Icon(Icons.power_rounded, size: 18),
                label: const Text('Включить связь с игрой'),
              )
            else
              OutlinedButton.icon(
                key: SettingsScreen.linkToggleKey,
                onPressed: busy ? null : () => _setLink(false),
                icon: const Icon(Icons.power_off_rounded, size: 18),
                label: const Text('Выключить связь'),
              ),
          ],
        ),
        const SizedBox(height: 16),
        Text(
          _hint(link.phase),
          style: const TextStyle(
            fontSize: 13,
            height: 1.45,
            color: AppColors.textMuted,
          ),
        ),
      ],
    );
  }

  static String _hint(LinkPhase phase) => switch (phase) {
        LinkPhase.off => 'Положите DirronliveBridge в папку mods, нажмите '
            '«Включить связь с игрой» и откройте одиночный мир. Порядок '
            'запуска программы и игры не важен.',
        LinkPhase.starting => 'Запускаю локальный сервер…',
        LinkPhase.waitingForMod => 'Сервер запущен. Запустите Minecraft с модом '
            'Dirronlive Bridge — он подключится сам за пару секунд.',
        LinkPhase.modConnected =>
          'Мод на связи. Откройте одиночный мир, чтобы подарки появлялись в игре.',
        LinkPhase.worldReady =>
          'Всё готово: нажмите «Тестовый подарок» на вкладке «Эфир».',
        LinkPhase.error =>
          'Устраните причину и нажмите «Повторить» или выключите связь.',
      };
}

class _Section extends StatelessWidget {
  const _Section({
    super.key,
    required this.anchor,
    required this.highlighted,
    required this.icon,
    required this.title,
    required this.child,
  });

  final GlobalKey anchor;
  final bool highlighted;
  final IconData icon;
  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      key: anchor,
      duration: const Duration(milliseconds: 250),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: highlighted ? AppColors.accent.withAlpha(22) : AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: highlighted ? AppColors.accent : AppColors.border,
          width: highlighted ? 2 : 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              IconBadge(icon: icon, size: 40),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: AppColors.text,
                  ),
                ),
              ),
              if (highlighted)
                const TagChip(label: 'Здесь', color: AppColors.accent),
            ],
          ),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }
}
