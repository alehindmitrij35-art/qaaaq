import 'package:flutter/material.dart';

/// Палитра Dirronlive, связанная с фирменным значком: глубокий сливовый фон,
/// яркий фиолетовый для управления, лаймовый для подтверждённых событий.
abstract final class AppColors {
  /// Фон окна — глубокий тёмно-сливовый.
  static const background = Color(0xFF100D19);

  /// Карточки и панели — светлее фона, лента и настройки отделяются.
  static const surface = Color(0xFF251C35);

  /// Чуть светлее карточек: заголовки таблиц, всплывающие сообщения.
  static const surfaceHigh = Color(0xFF30254A);

  /// Чередующиеся строки таблицы.
  static const surfaceAlt = Color(0xFF1D1629);

  static const border = Color(0xFF3B2D57);

  /// Управление: главные кнопки, активные элементы.
  static const accent = Color(0xFFA78BFA);

  /// Розовый — переход на линии вкладки и подсветка новых подарков.
  static const accentAlt = Color(0xFFE879F9);

  /// Тёмный текст на фиолетовых кнопках.
  static const onAccent = Color(0xFF160C26);

  /// Основной текст.
  static const text = Color(0xFFF7F3FF);

  /// Второстепенный текст.
  static const textMuted = Color(0xFFC3B8D1);

  /// Третьестепенный: время, подписи к полям.
  static const textFaint = Color(0xFF8F83A3);

  /// Успешное подключение и доставка в игру — лаймовый.
  static const success = Color(0xFFA3FF47);

  /// Ожидание: «Подключение…», «Отправляется».
  static const warning = Color(0xFFFFC857);

  /// Ошибка — коралловый.
  static const danger = Color(0xFFFF7A90);

  /// Фиолетово-розовый переход: линия активной вкладки, подсветка подарка.
  static const brandGradient = LinearGradient(
    begin: Alignment.centerLeft,
    end: Alignment.centerRight,
    colors: [accent, accentAlt],
  );

  static const brandGradientVertical = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [accent, accentAlt],
  );
}
