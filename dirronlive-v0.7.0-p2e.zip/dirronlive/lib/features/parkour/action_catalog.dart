/// Каталог действий карты «Dirron Parkour: 100 комнат» — 24 действия.
///
/// Те же ID понимает мод (ParkourActions.java). Параметры — значения по
/// умолчанию, которые можно поменять в правиле.
library;

enum ParamKind { integer, decimal, choice }

class ActionParam {
  const ActionParam({
    required this.key,
    required this.label,
    required this.kind,
    required this.defaultValue,
    this.min = 0,
    this.max = 100,
    this.step = 1,
    this.unit = '',
    this.choices = const {},
  });

  final String key;
  final String label;
  final ParamKind kind;
  final Object defaultValue;
  final num min;
  final num max;
  final num step;
  final String unit;

  /// Для [ParamKind.choice]: значение → подпись.
  final Map<String, String> choices;

  /// Приводит значение из правила к допустимому.
  Object normalize(Object? value) {
    switch (kind) {
      case ParamKind.choice:
        return value is String && choices.containsKey(value) ? value : defaultValue;
      case ParamKind.integer:
        final n = value is num ? value.round() : (defaultValue as num).round();
        return n.clamp(min.round(), max.round());
      case ParamKind.decimal:
        final n = value is num ? value.toDouble() : (defaultValue as num).toDouble();
        final clamped = n.clamp(min.toDouble(), max.toDouble());
        return (clamped * 10).round() / 10;
    }
  }

  String format(Object? value) {
    final v = normalize(value);
    if (kind == ParamKind.choice) return choices[v] ?? '$v';
    final text = v is double ? v.toStringAsFixed(1).replaceAll('.', ',') : '$v';
    return unit.isEmpty ? text : '$text $unit';
  }
}

class ParkourAction {
  const ParkourAction({
    required this.id,
    required this.title,
    required this.description,
    this.hindrance = false,
    this.params = const [],
  });

  final String id;
  final String title;
  final String description;

  /// «Помеха» — её гасит «Щит от пакости» и откладывает «Второй шанс».
  final bool hindrance;
  final List<ActionParam> params;

  Map<String, Object> defaults() => {for (final p in params) p.key: p.defaultValue};

  /// Параметры правила, приведённые к допустимым значениям.
  Map<String, Object> normalize(Map<String, Object?> values) =>
      {for (final p in params) p.key: p.normalize(values[p.key])};

  /// «3 комнаты · 5 с»
  String summary(Map<String, Object?> values) =>
      params.map((p) => '${p.label}: ${p.format(values[p.key])}').join(' · ');
}

const _seconds = 'с';

ActionParam _secondsParam(int value, {int max = 60}) => ActionParam(
      key: 'seconds',
      label: 'Длительность',
      kind: ParamKind.integer,
      defaultValue: value,
      min: 1,
      max: max,
      unit: _seconds,
    );

const _directions = {
  'random': 'в случайную сторону',
  'forward': 'вперёд',
  'back': 'назад',
  'left': 'влево',
  'right': 'вправо',
};

final parkourActions = <ParkourAction>[
  const ParkourAction(
    id: 'room_forward',
    title: 'Комната вперёд',
    description: 'Игрок переносится на старт следующей комнаты.',
    params: [
      ActionParam(key: 'rooms', label: 'Комнат', kind: ParamKind.integer, defaultValue: 1, min: 1, max: 99),
    ],
  ),
  const ParkourAction(
    id: 'room_back',
    title: 'Комната назад',
    description: 'Игрок возвращается на старт предыдущей комнаты.',
    hindrance: true,
    params: [
      ActionParam(key: 'rooms', label: 'Комнат', kind: ParamKind.integer, defaultValue: 1, min: 1, max: 99),
    ],
  ),
  const ParkourAction(
    id: 'big_rollback',
    title: 'Большой откат',
    description: 'Откат на несколько комнат назад.',
    hindrance: true,
    params: [
      ActionParam(key: 'rooms', label: 'Комнат', kind: ParamKind.integer, defaultValue: 5, min: 1, max: 99),
    ],
  ),
  const ParkourAction(
    id: 'restart_room',
    title: 'Снова со старта',
    description: 'Игрок возвращается на старт текущей комнаты.',
    hindrance: true,
  ),
  const ParkourAction(
    id: 'fall_rescue',
    title: 'Спасение от падения',
    description: 'Следующее падение вернёт на последнюю платформу, а не на чекпоинт.',
    params: [
      ActionParam(key: 'charges', label: 'Зарядов', kind: ParamKind.integer, defaultValue: 1, min: 1, max: 10),
    ],
  ),
  const ParkourAction(
    id: 'personal_checkpoint',
    title: 'Личный чекпоинт',
    description: 'Чекпоинт ставится там, где стоит игрок (после приземления).',
  ),
  ParkourAction(
    id: 'champion_jump',
    title: 'Прыжок чемпиона',
    description: 'Прыжки выше на несколько секунд.',
    params: [
      _secondsParam(5),
      const ActionParam(key: 'power', label: 'Сила', kind: ParamKind.integer, defaultValue: 2, min: 1, max: 5),
    ],
  ),
  ParkourAction(
    id: 'sprint',
    title: 'Спринт',
    description: 'Игрок бегает быстрее.',
    params: [
      _secondsParam(5),
      const ActionParam(key: 'power', label: 'Сила', kind: ParamKind.integer, defaultValue: 2, min: 1, max: 5),
    ],
  ),
  ParkourAction(
    id: 'heavy_boots',
    title: 'Тяжёлые ботинки',
    description: 'Игрок замедляется.',
    hindrance: true,
    params: [
      _secondsParam(4),
      const ActionParam(key: 'power', label: 'Сила', kind: ParamKind.integer, defaultValue: 2, min: 1, max: 5),
    ],
  ),
  const ParkourAction(
    id: 'lightning',
    title: 'Удар молнией',
    description: 'Молния бьёт рядом с игроком (без огня и урона) и отбрасывает его в случайную сторону.',
    hindrance: true,
    params: [
      ActionParam(
          key: 'strength', label: 'Сила отдачи', kind: ParamKind.decimal, defaultValue: 1.5, min: 0.3, max: 5, step: 0.1),
    ],
  ),
  ParkourAction(
    id: 'freeze',
    title: 'Заморозка',
    description: 'Игрок не может двигаться и прыгать.',
    hindrance: true,
    params: [_secondsParam(2, max: 15)],
  ),
  const ParkourAction(
    id: 'push',
    title: 'Толчок',
    description: 'Толчок относительно взгляда игрока. Если сбросило — карта вернёт на чекпоинт.',
    hindrance: true,
    params: [
      ActionParam(
          key: 'direction', label: 'Направление', kind: ParamKind.choice, defaultValue: 'random', choices: _directions),
      ActionParam(
          key: 'strength', label: 'Сила', kind: ParamKind.decimal, defaultValue: 1.0, min: 0.1, max: 5, step: 0.1),
    ],
  ),
  const ParkourAction(
    id: 'trampoline',
    title: 'Батут под ногами',
    description: 'Подбрасывает вверх (если игрок в воздухе — после приземления).',
    params: [
      ActionParam(key: 'power', label: 'Высота', kind: ParamKind.decimal, defaultValue: 1.2, min: 0.4, max: 3, step: 0.1),
    ],
  ),
  ParkourAction(
    id: 'soft_landing',
    title: 'Мягкая посадка',
    description: 'Медленное падение.',
    params: [_secondsParam(6)],
  ),
  ParkourAction(
    id: 'safety_platform',
    title: 'Страховочная платформа',
    description: 'При следующем падении под игроком появится стеклянная платформа.',
    params: [_secondsParam(3, max: 30)],
  ),
  ParkourAction(
    id: 'viewer_bridge',
    title: 'Мост зрителя',
    description: 'Временный мост между первыми платформами комнаты.',
    params: [_secondsParam(5)],
  ),
  ParkourAction(
    id: 'secret_shortcut',
    title: 'Секретная срезка',
    description: 'Временная дорожка в обход нескольких прыжков.',
    params: [_secondsParam(8)],
  ),
  ParkourAction(
    id: 'vanishing_step',
    title: 'Исчезающая ступень',
    description: 'Следующая платформа мигает секунду и исчезает.',
    hindrance: true,
    params: [_secondsParam(3, max: 30)],
  ),
  ParkourAction(
    id: 'show_route',
    title: 'Покажи маршрут',
    description: 'Частицы показывают следующие прыжки.',
    params: [_secondsParam(5)],
  ),
  const ParkourAction(
    id: 'shield',
    title: 'Щит от пакости',
    description: 'Гасит следующую помеху от зрителей.',
    params: [
      ActionParam(key: 'charges', label: 'Зарядов', kind: ParamKind.integer, defaultValue: 1, min: 1, max: 10),
    ],
  ),
  ParkourAction(
    id: 'second_chance',
    title: 'Второй шанс от чата',
    description: 'Помехи от зрителей ждут обратного отсчёта. Если за это время придёт '
        'этот подарок — помеха отменяется.',
    params: [_secondsParam(10, max: 60)],
  ),
  const ParkourAction(
    id: 'to_last_level',
    title: 'На последний уровень',
    description: 'Старт комнаты 100 лицом к первому прыжку, чекпоинт обновляется.',
  ),
  const ParkourAction(
    id: 'to_first_level',
    title: 'На первый уровень',
    description: 'Старт комнаты 1. Счётчик падений и время сохраняются.',
    hindrance: true,
  ),
  const ParkourAction(
    id: 'super_push',
    title: 'СУПЕР СИЛЬНЫЙ ТОЛЧОК',
    description: 'Мощный импульс с подбросом относительно взгляда игрока.',
    hindrance: true,
    params: [
      ActionParam(
          key: 'direction', label: 'Направление', kind: ParamKind.choice, defaultValue: 'random', choices: _directions),
      ActionParam(
          key: 'strength', label: 'Сила (×обычного)', kind: ParamKind.decimal, defaultValue: 3.0, min: 0.5, max: 10, step: 0.5),
      ActionParam(
          key: 'lift', label: 'Высота подброса', kind: ParamKind.decimal, defaultValue: 0.8, min: 0, max: 3, step: 0.1),
    ],
  ),
];

final Map<String, ParkourAction> _byId = {for (final a in parkourActions) a.id: a};

ParkourAction? parkourActionById(String id) => _byId[id];

/// Группа действия: цвет карточки в окне выбора.
enum ActionCategory {
  /// Перемещение по комнатам — фиолетовый.
  move('Перемещение'),

  /// Помощь игроку — лайм.
  help('Помощь'),

  /// Помеха — коралловый.
  hindrance('Помеха');

  const ActionCategory(this.label);

  final String label;
}

const _moveIds = {
  'room_forward', 'room_back', 'big_rollback', 'restart_room', 'to_first_level', 'to_last_level',
};

extension ParkourActionLook on ParkourAction {
  ActionCategory get category {
    if (_moveIds.contains(id)) return ActionCategory.move;
    return hindrance ? ActionCategory.hindrance : ActionCategory.help;
  }

  /// Короткая подсказка для окна выбора.
  String get hint => _hints[id] ?? description;
}

const _hints = <String, String>{
  'room_forward': 'Переносит на старт следующей комнаты',
  'room_back': 'Возвращает на старт предыдущей комнаты',
  'big_rollback': 'Откатывает на 5 комнат назад',
  'restart_room': 'Возвращает на старт этой комнаты',
  'fall_rescue': 'Следующее падение — на последнюю платформу',
  'personal_checkpoint': 'Ставит чекпоинт там, где стоит игрок',
  'champion_jump': 'Прыжки выше на 5 секунд',
  'sprint': 'Бег быстрее на 5 секунд',
  'heavy_boots': 'Замедляет на 4 секунды',
  'freeze': 'Нельзя двигаться 2 секунды',
  'push': 'Толкает в сторону по взгляду',
  'trampoline': 'Подбрасывает вверх',
  'soft_landing': 'Медленное падение 6 секунд',
  'safety_platform': 'Стекло под ногами при падении',
  'viewer_bridge': 'Мост через первый разрыв на 5 секунд',
  'secret_shortcut': 'Дорожка в обход прыжков на 8 секунд',
  'vanishing_step': 'Следующая платформа исчезает',
  'show_route': 'Частицы показывают прыжки',
  'shield': 'Гасит следующую помеху',
  'second_chance': 'Помеха ждёт отсчёта — чат может отменить',
  'to_last_level': 'Переносит на старт комнаты 100',
  'to_first_level': 'Переносит на старт комнаты 1',
  'super_push': 'Мощный толчок ×3 с подбросом',
};
