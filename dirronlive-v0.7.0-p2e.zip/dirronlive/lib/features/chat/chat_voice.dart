import 'dart:async';
import 'dart:collection';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:crypto/crypto.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/events/gift_event.dart';
import '../../core/events/stream_events.dart';
import '../../core/providers.dart';
import '../minecraft/minecraft_link.dart';
import 'chat_settings.dart';

/// Что и как сказать: текст и интонация (проценты для SSML).
class SpeechLine {
  const SpeechLine({
    required this.text,
    required this.voice,
    this.rate = 0,
    this.pitch = 0,
    this.volume = 0,
  });

  final String text;
  final String voice;
  final int rate;
  final int pitch;
  final int volume;

  static String _pct(int v) => '${v >= 0 ? '+' : ''}$v%';

  /// SSML для нейроголоса: один голос, одна интонация (так принимает сервис).
  String ssml() => "<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='ru-RU'>"
      "<voice name='$voice'><prosody pitch='${_pct(pitch)}' rate='${_pct(rate)}' volume='${_pct(volume)}'>"
      '${_xml(text)}</prosody></voice></speak>';

  static String _xml(String s) => s
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&apos;');
}

/// Превращает сообщение чата в выразительную фразу. Чистая функция — проверяется тестами.
abstract final class ChatSpeech {
  static const _neural = ['ru-RU-SvetlanaNeural', 'ru-RU-DmitryNeural'];

  static const _emoji = <String, String>{
    '😂': ' ха-ха! ',
    '🤣': ' ха-ха-ха! ',
    '😭': ' ой-ой! ',
    '❤': ' люблю! ',
    '❤️': ' люблю! ',
    '🔥': ' огонь! ',
    '👍': ' класс! ',
    '😮': ' ого! ',
    '😱': ' ого! ',
    '👋': ' привет! ',
  };

  /// Стабильное число зрителя: свой голос и своя высота в режиме «Разные голоса».
  static int _hash(String s) {
    var h = 0;
    for (final c in s.codeUnits) {
      h = (h * 31 + c) & 0x7fffffff;
    }
    return h;
  }

  /// Чистка текста: ссылки, эмодзи, растянутые буквы, обрезка по длине.
  static String clean(String text, ChatSettings s) {
    var t = text;
    if (s.skipLinks) t = t.replaceAll(RegExp(r'(https?://|www\.)\S+', caseSensitive: false), ' ссылка ');
    _emoji.forEach((k, v) => t = t.replaceAll(k, v));
    // Оставшиеся эмодзи и значки — молча убрать.
    t = t.replaceAll(RegExp(r'[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}\u{200D}]', unicode: true), ' ');
    // «ааааа» → «ааа», «!!!!!» → «!!!».
    t = t.replaceAllMapped(RegExp(r'(.)\1{3,}', unicode: true), (m) => m[1]! * 3);
    t = t.replaceAll(RegExp(r'\s+'), ' ').trim();
    if (t.length > s.maxLength) t = '${t.substring(0, s.maxLength).trimRight()}…';
    return t;
  }

  /// Фраза для зрителя [name] или `null`, если говорить нечего.
  static SpeechLine? line(String viewerId, String name, String text, ChatSettings s) {
    final body = clean(text, s);
    if (body.replaceAll(RegExp(r'[^\p{L}\p{N}]', unicode: true), '').isEmpty) return null;
    final h = _hash(viewerId.isEmpty ? name : viewerId);
    final voice = switch (s.voiceName) {
      'mix' => _neural[h % _neural.length],
      final v => v,
    };
    var rate = s.rate;
    var pitch = s.voiceName == 'mix' ? (h % 13) - 6 : 0;
    var volume = 0;
    if (s.expressive) {
      final letters = body.replaceAll(RegExp(r'[^\p{L}]', unicode: true), '');
      final shouting = letters.length >= 5 && letters == letters.toUpperCase() && letters != letters.toLowerCase();
      final laugh = RegExp(r'(ха){2,}|(ах){2,}|(хе){2,}|lol|ха-ха', caseSensitive: false).hasMatch(body);
      if (body.contains('!')) {
        rate += 8;
        pitch += 8;
      }
      if (body.trimRight().endsWith('?')) pitch += 5;
      if (shouting) {
        volume += 20;
        rate += 5;
        pitch += 4;
      }
      if (laugh) pitch += 10;
    }
    final spoken = caps(body) ? body.toLowerCase() : body; // капс иначе читается по буквам
    final cleanName = name.replaceAll(RegExp(r'[_.]+'), ' ').trim();
    final phrase = s.readNames && cleanName.isNotEmpty ? '$cleanName: $spoken' : spoken;
    return SpeechLine(
      text: phrase,
      voice: voice,
      rate: rate.clamp(-50, 100).toInt(),
      pitch: pitch.clamp(-30, 30).toInt(),
      volume: volume.clamp(-50, 50).toInt(),
    );
  }

  static bool caps(String body) {
    final letters = body.replaceAll(RegExp(r'[^\p{L}]', unicode: true), '');
    return letters.length >= 5 && letters == letters.toUpperCase() && letters != letters.toLowerCase();
  }
}

/// Нейроголоса Microsoft — тот же сервис, что «Читать вслух» в Edge.
class EdgeTts {
  static const _token = '6A5AA1D4EAFF4E9FB37E23D68491D6F4';
  static const _version = '130.0.2849.68';

  /// Пропуск сервиса: SHA-256 от времени (шаг 5 минут) и токена.
  static String secMsGec(DateTime now) {
    var ticks = now.toUtc().millisecondsSinceEpoch ~/ 1000 + 11644473600;
    ticks -= ticks % 300;
    return sha256.convert(ascii.encode('${ticks}0000000$_token')).toString().toUpperCase();
  }

  static String _id() {
    final r = Random();
    return List.generate(32, (_) => r.nextInt(16).toRadixString(16)).join();
  }

  /// MP3 с фразой. Бросает исключение, если сервис недоступен.
  Future<List<int>> synthesize(SpeechLine line) async {
    final url = 'wss://speech.platform.bing.com/consumer/speech/synthesize/readaloud/edge/v1'
        '?TrustedClientToken=$_token&Sec-MS-GEC=${secMsGec(DateTime.now())}'
        '&Sec-MS-GEC-Version=1-$_version&ConnectionId=${_id()}';
    final ws = await WebSocket.connect(url, headers: {
      'Pragma': 'no-cache',
      'Cache-Control': 'no-cache',
      'Origin': 'chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold',
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
          'Chrome/130.0.0.0 Safari/537.36 Edg/$_version',
      'Accept-Language': 'en-US,en;q=0.9',
      'Cookie': 'muid=${_id().toUpperCase()};',
    }).timeout(const Duration(seconds: 8));
    final audio = <int>[];
    final done = Completer<void>();
    final sub = ws.listen((data) {
      if (data is String) {
        if (data.contains('Path:turn.end') && !done.isCompleted) done.complete();
      } else if (data is List<int> && data.length > 2) {
        final headerLength = (data[0] << 8) | data[1];
        if (2 + headerLength > data.length) return;
        final header = ascii.decode(data.sublist(2, 2 + headerLength), allowInvalid: true);
        if (header.contains('Path:audio')) audio.addAll(data.sublist(2 + headerLength));
      }
    }, onError: (Object e) {
      if (!done.isCompleted) done.completeError(e);
    }, onDone: () {
      if (!done.isCompleted) done.complete();
    });
    final stamp = DateTime.now().toUtc().toIso8601String();
    ws.add('X-Timestamp:$stamp\r\nContent-Type:application/json; charset=utf-8\r\nPath:speech.config\r\n\r\n'
        '{"context":{"synthesis":{"audio":{"metadataoptions":{"sentenceBoundaryEnabled":"false",'
        '"wordBoundaryEnabled":"false"},"outputFormat":"audio-24khz-48kbitrate-mono-mp3"}}}}\r\n');
    ws.add('X-RequestId:${_id()}\r\nContent-Type:application/ssml+xml\r\nX-Timestamp:${stamp}Z\r\n'
        'Path:ssml\r\n\r\n${line.ssml()}');
    try {
      await done.future.timeout(const Duration(seconds: 15));
    } finally {
      await sub.cancel();
      unawaited(ws.close());
    }
    if (audio.isEmpty) throw StateError('нейроголос не прислал звук');
    return audio;
  }
}

/// Проигрыватель: один процесс PowerShell играет MP3 и говорит голосом Windows.
class VoiceHost {
  Process? _process;
  StreamSubscription<String>? _lines;
  Completer<void>? _waiting;

  /// Есть ли в Windows русский голос (null — ещё неизвестно).
  bool? russianVoice;

  /// Последняя ошибка проигрывателя.
  String? lastError;

  static const _script = r'''
$ErrorActionPreference = 'SilentlyContinue'
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName System.Speech
$synth = New-Object System.Speech.Synthesis.SpeechSynthesizer
$ru = $synth.GetInstalledVoices() | Where-Object { $_.VoiceInfo.Culture.Name -like 'ru*' } | Select-Object -First 1
if ($ru) { $synth.SelectVoice($ru.VoiceInfo.Name); [Console]::Out.WriteLine('ruvoice yes') } else { [Console]::Out.WriteLine('ruvoice no') }
[Console]::Out.Flush()
$wmp = $null
try { $wmp = New-Object -ComObject WMPlayer.OCX } catch {}
while ($true) {
  $line = [Console]::In.ReadLine()
  if ($line -eq $null) { break }
  try {
    $cmd = $line | ConvertFrom-Json
    $text = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($cmd.b64))
    if ($cmd.kind -eq 'mp3') {
      if ($wmp) {
        # Windows Media Player: ждём настоящий конец звука, ничего не обрезается.
        $wmp.settings.volume = [int]([double]$cmd.volume * 100)
        $wmp.URL = $text
        $wmp.controls.play()
        $t = 0
        while ($wmp.playState -ne 3 -and $t -lt 3000) { Start-Sleep -Milliseconds 30; $t += 30 }
        $t = 0
        while (($wmp.playState -eq 3 -or $wmp.playState -eq 6 -or $wmp.playState -eq 9) -and $t -lt ([int]$cmd.ms + 5000)) {
          Start-Sleep -Milliseconds 40; $t += 40
        }
        $wmp.controls.stop()
        $wmp.close()
      } else {
        $p = New-Object System.Windows.Media.MediaPlayer
        $p.Volume = [double]$cmd.volume
        $p.Open([Uri]$text)
        Start-Sleep -Milliseconds 300
        $p.Play()
        Start-Sleep -Milliseconds ([int]$cmd.ms)
        $p.Close()
      }
      Remove-Item -LiteralPath $text -Force
    } else {
      $synth.Volume = [int]$cmd.volume100
      $synth.Rate = [int]$cmd.rate10
      $synth.Speak($text)
    }
  } catch { [Console]::Out.WriteLine('error ' + $_.Exception.Message) }
  [Console]::Out.WriteLine('done')
  [Console]::Out.Flush()
}
''';

  Future<void> _ensure() async {
    if (_process != null) return;
    // Скрипт — в файл (UTF-8 с BOM для PowerShell 5), стандартный ввод — только для команд.
    final script = File('${Directory.systemTemp.path}${Platform.pathSeparator}dirronlive-voice.ps1');
    await script.writeAsBytes([0xEF, 0xBB, 0xBF, ...utf8.encode(_script)], flush: true);
    final p = await Process.start('powershell',
        ['-NoProfile', '-NonInteractive', '-STA', '-ExecutionPolicy', 'Bypass', '-File', script.path]);
    _process = p;
    _lines = p.stdout.transform(const SystemEncoding().decoder).transform(const LineSplitter()).listen((l) {
      final line = l.trim();
      if (line.startsWith('ruvoice ')) russianVoice = line.endsWith('yes');
      if (line.startsWith('error ')) lastError = line.substring(6);
      if (line == 'done') {
        final w = _waiting;
        _waiting = null;
        if (w != null && !w.isCompleted) w.complete();
      }
    });
    unawaited(p.exitCode.then((_) {
      _process = null;
      final w = _waiting;
      _waiting = null;
      if (w != null && !w.isCompleted) w.complete();
    }));
  }

  /// Запустить проигрыватель заранее: первая фраза не ждёт запуска PowerShell.
  Future<void> warmUp() async {
    try {
      await _ensure();
    } catch (_) {
      // Нет PowerShell (не Windows) — скажем об ошибке при первой фразе.
    }
  }

  Future<void> _run(Map<String, Object?> cmd, Duration limit) async {
    await _ensure();
    final w = Completer<void>();
    _waiting = w;
    _process?.stdin.writeln(jsonEncode(cmd));
    await w.future.timeout(limit, onTimeout: () {});
  }

  /// Проиграть MP3 (файл удаляется после).
  Future<void> playMp3(List<int> bytes, double volume) async {
    final file = File('${Directory.systemTemp.path}${Platform.pathSeparator}dirronlive-tts-'
        '${DateTime.now().microsecondsSinceEpoch}.mp3');
    await file.writeAsBytes(bytes, flush: true);
    // 48 кбит/с: длительность по размеру файла.
    final ms = (bytes.length * 8 / 48).round() + 250;
    await _run({'kind': 'mp3', 'b64': base64Encode(utf8.encode(file.path)), 'volume': volume, 'ms': ms},
        Duration(milliseconds: ms + 5000));
  }

  /// Сказать голосом Windows (без интернета).
  Future<void> speakWindows(String text, int volume, int ratePercent) => _run({
        'kind': 'sapi',
        'b64': base64Encode(utf8.encode(text)),
        'volume100': volume.clamp(0, 100),
        'rate10': (ratePercent / 10).round().clamp(-10, 10),
      }, const Duration(seconds: 40));

  Future<void> dispose() async {
    await _lines?.cancel();
    _process?.kill();
    _process = null;
  }
}

/// Говорилка: нейроголос с запасным голосом Windows.
///
/// Фраза готовится ([prepare]: синтез нейроголоса) отдельно от
/// произнесения ([sayPrepared]) — пока звучит одна, следующая уже готовится.
abstract class ChatSpeaker {
  /// Сказать фразу; вернуть, каким голосом сказано (для экрана «Озвучка»).
  Future<String> say(SpeechLine line, ChatSettings settings);

  /// Заранее подготовить звук фразы (или `null` — готовить нечего).
  Future<Object?> prepare(SpeechLine line, ChatSettings settings) async => null;

  /// Сказать подготовленную фразу.
  Future<String> sayPrepared(SpeechLine line, ChatSettings settings, Object? prepared) => say(line, settings);

  /// Запустить проигрыватель заранее.
  Future<void> warmUp() async {}

  Future<void> dispose();
}

class _Mp3 {
  const _Mp3(this.bytes);
  final List<int> bytes;
}

class WindowsChatSpeaker extends ChatSpeaker {
  final _edge = EdgeTts();
  final _host = VoiceHost();
  DateTime? _edgeDownUntil;

  String? _edgeError;

  @override
  Future<void> warmUp() => _host.warmUp();

  @override
  Future<Object?> prepare(SpeechLine line, ChatSettings s) async {
    final now = DateTime.now();
    final useEdge = s.voiceName != 'windows' && (_edgeDownUntil == null || now.isAfter(_edgeDownUntil!));
    if (!useEdge) return null;
    try {
      return _Mp3(await _edge.synthesize(line));
    } catch (e) {
      // Нейроголос недоступен — минуту говорим голосом Windows.
      _edgeDownUntil = now.add(const Duration(minutes: 1));
      _edgeError = '$e';
      return null;
    }
  }

  @override
  Future<String> sayPrepared(SpeechLine line, ChatSettings s, Object? prepared) async {
    if (prepared is _Mp3) {
      await _host.playMp3(prepared.bytes, s.volume / 100);
      _edgeError = null;
      final err = _host.lastError;
      _host.lastError = null;
      return err == null ? 'нейроголос ${line.voice}' : 'нейроголос, ошибка проигрывателя: $err';
    }
    await _host.speakWindows(line.text, s.volume, line.rate);
    final parts = <String>[
      'голос Windows',
      if (_host.russianVoice == false) 'русского голоса в Windows нет — установите: Параметры → Время и язык → Речь',
      if (s.voiceName != 'windows' && _edgeError != null) 'нейроголос недоступен: $_edgeError',
    ];
    return parts.join(' · ');
  }

  @override
  Future<String> say(SpeechLine line, ChatSettings s) async => sayPrepared(line, s, await prepare(line, s));

  @override
  Future<void> dispose() => _host.dispose();
}

final chatSpeakerProvider = Provider<ChatSpeaker>((ref) {
  final speaker = WindowsChatSpeaker();
  ref.onDispose(speaker.dispose);
  return speaker;
});

/// Состояние озвучки для экрана: сколько в очереди, последняя ошибка.
class ChatRelayState {
  const ChatRelayState({this.queued = 0, this.spoken = 0, this.lastSpoken, this.engine});
  final int queued;
  final int spoken;
  final String? lastSpoken;

  /// Каким голосом сказана последняя фраза (и почему не нейроголосом).
  final String? engine;
}

/// Запись истории озвучки.
class VoiceHistoryEntry {
  const VoiceHistoryEntry({
    required this.at,
    required this.viewer,
    required this.message,
    required this.line,
    required this.status,
    this.engine = '',
    this.waitMs = 0,
    this.reason = '',
  });

  /// Когда пришло сообщение.
  final DateTime at;
  final String viewer;

  /// Сообщение как в чате (после чистки).
  final String message;

  /// Что сказано (для «Повторить»).
  final SpeechLine line;

  /// spoken — озвучено, skipped — пропущено, error — ошибка.
  final String status;
  final String engine;

  /// Сколько сообщение ждало до начала звука.
  final int waitMs;
  final String reason;
}

/// История озвучки: последние [VoiceHistory.limit] сообщений (только в памяти).
final voiceHistoryProvider = NotifierProvider<VoiceHistory, List<VoiceHistoryEntry>>(VoiceHistory.new);

class VoiceHistory extends Notifier<List<VoiceHistoryEntry>> {
  static const limit = 200;

  @override
  List<VoiceHistoryEntry> build() => const [];

  void add(VoiceHistoryEntry e) {
    final next = [e, ...state];
    state = next.length > limit ? next.sublist(0, limit) : next;
  }

  void clear() => state = const [];

  /// Средняя задержка последних озвученных (мс) или `null`.
  int? averageWaitMs({int last = 20}) {
    final spoken = state.where((e) => e.status == 'spoken').take(last).toList();
    if (spoken.isEmpty) return null;
    return spoken.fold<int>(0, (sum, e) => sum + e.waitMs) ~/ spoken.length;
  }
}

/// Фраза в очереди.
class _VoiceItem {
  _VoiceItem(this.line, this.settings, this.viewer, this.message, this.at);

  final SpeechLine line;
  final ChatSettings settings;
  final String viewer;
  final String message;
  final DateTime at;
  Future<Object?>? prepared;
}

/// Чат TikTok → чат Minecraft и озвучка (по настройкам «кого»).
final chatRelayProvider = NotifierProvider<ChatRelay, ChatRelayState>(ChatRelay.new);

class ChatRelay extends Notifier<ChatRelayState> {
  static const maxQueue = 5;
  static const _colors = ['gold', 'light_purple', 'green', 'aqua', 'yellow', 'red', 'blue'];

  final Queue<_VoiceItem> _queue = Queue();
  final Set<String> _gifters = {};
  bool _speaking = false;
  bool _disposed = false;
  StreamSubscription<ChatEvent>? _chat;
  StreamSubscription<GiftEvent>? _gifts;

  @override
  ChatRelayState build() {
    final bus = ref.read(eventBusProvider);
    _chat = bus.on<ChatEvent>().listen(_onChat);
    _gifts = bus.on<GiftEvent>().listen((g) {
      if (g.viewerId != null) _gifters.add(g.viewerId!);
      _gifters.add(g.viewerName.toLowerCase());
    });
    // Озвучку включили — сразу запустить проигрыватель, чтобы первая фраза не ждала.
    ref.listen<ChatSettings>(chatSettingsProvider, (prev, next) {
      if (next.voice && !(prev?.voice ?? false)) unawaited(ref.read(chatSpeakerProvider).warmUp());
    }, fireImmediately: true);
    ref.onDispose(() {
      _disposed = true;
      unawaited(_chat?.cancel());
      unawaited(_gifts?.cancel());
      _queue.clear();
    });
    return const ChatRelayState();
  }

  Set<String> get gifters => _gifters;

  VoiceHistory get _history => ref.read(voiceHistoryProvider.notifier);

  void _onChat(ChatEvent e) {
    final s = ref.read(chatSettingsProvider);
    final viewer = ChatViewer(
      id: e.viewerId,
      name: e.viewerName,
      follower: e.isFollower,
      fan: e.isFan,
      subscriber: e.isSubscriber,
      moderator: e.isModerator,
    );
    if (s.minecraft && s.passes(s.minecraftWho, viewer, _gifters)) {
      sendToMinecraft(e.viewerId, e.viewerName, e.text);
    }
    if (s.voice && s.passes(s.voiceWho, viewer, _gifters)) {
      final line = ChatSpeech.line(e.viewerId, e.viewerName, e.text, s);
      if (line != null) enqueue(line, s, viewer: e.viewerName, message: ChatSpeech.clean(e.text, s));
    }
  }

  bool sendToMinecraft(String viewerId, String name, String text) {
    var h = 0;
    for (final c in viewerId.codeUnits) {
      h = (h * 31 + c) & 0x7fffffff;
    }
    return ref.read(minecraftLinkProvider.notifier).sendChat(name, text, _colors[h % _colors.length]);
  }

  /// В очереди не больше [maxQueue] фраз: при наплыве старые пропускаются.
  void enqueue(SpeechLine line, ChatSettings s, {String viewer = '', String? message}) {
    _queue.add(_VoiceItem(line, s, viewer, message ?? line.text, DateTime.now()));
    while (_queue.length > maxQueue) {
      _skip(_queue.removeFirst(), 'много сообщений сразу — старое пропущено');
    }
    _publish();
    unawaited(_drain());
  }

  /// «Повторить» из истории.
  void replay(VoiceHistoryEntry e) =>
      enqueue(e.line, ref.read(chatSettingsProvider), viewer: e.viewer, message: e.message);

  void _publish() {
    if (_disposed) return;
    state = ChatRelayState(
        queued: _queue.length, spoken: state.spoken, lastSpoken: state.lastSpoken, engine: state.engine);
  }

  void _skip(_VoiceItem item, String reason) {
    if (_disposed) return;
    _history.add(VoiceHistoryEntry(
      at: item.at,
      viewer: item.viewer,
      message: item.message,
      line: item.line,
      status: 'skipped',
      waitMs: DateTime.now().difference(item.at).inMilliseconds,
      reason: reason,
    ));
  }

  bool _stale(_VoiceItem item) {
    final limit = item.settings.maxDelay;
    return limit > 0 && DateTime.now().difference(item.at).inSeconds >= limit;
  }

  _VoiceItem _prepare(ChatSpeaker speaker, _VoiceItem item) {
    item.prepared = speaker.prepare(item.line, item.settings).catchError((Object _) => null);
    return item;
  }

  /// Озвучка по очереди. Следующая фраза синтезируется, пока звучит текущая,
  /// поэтому между сообщениями почти нет паузы.
  Future<void> _drain() async {
    if (_speaking) return;
    _speaking = true;
    final speaker = ref.read(chatSpeakerProvider);
    _VoiceItem? ahead;
    try {
      while (!_disposed && (_queue.isNotEmpty || ahead != null)) {
        final item = ahead ?? _prepare(speaker, _queue.removeFirst());
        ahead = null;
        _publish();
        final prepared = await item.prepared;
        if (_disposed) return;
        if (_queue.isNotEmpty) {
          ahead = _prepare(speaker, _queue.removeFirst());
          _publish();
        }
        if (_stale(item)) {
          _skip(item, 'ждало дольше ${item.settings.maxDelay} с — чат ушёл вперёд');
          continue;
        }
        final started = DateTime.now();
        var status = 'spoken';
        String engine;
        try {
          engine = await speaker.sayPrepared(item.line, item.settings, prepared);
        } catch (e) {
          engine = 'ошибка озвучки: $e';
          status = 'error';
        }
        if (_disposed) return;
        state = ChatRelayState(queued: _queue.length, spoken: state.spoken + 1, lastSpoken: item.line.text, engine: engine);
        _history.add(VoiceHistoryEntry(
          at: item.at,
          viewer: item.viewer,
          message: item.message,
          line: item.line,
          status: status,
          engine: engine,
          waitMs: started.difference(item.at).inMilliseconds,
        ));
      }
    } finally {
      _speaking = false;
    }
  }

  /// Кнопка «Проверить»: фраза без отбора и в Minecraft, если включено.
  void test() {
    final s = ref.read(chatSettingsProvider);
    const text = 'Привет! Это проверка озвучки чата. Как слышно?';
    final line = ChatSpeech.line('test-viewer', 'Mira', text, s);
    if (line != null) enqueue(line, s, viewer: 'Mira (проверка)', message: text);
    if (s.minecraft) sendToMinecraft('test-viewer', 'Mira', text);
  }
}

/// Создать ретранслятор при запуске (иначе он не слушает шину).
void startChatRelay(ProviderContainer container) => container.read(chatRelayProvider);
