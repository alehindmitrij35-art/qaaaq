package dev.dirronlive.parkour.map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.Test;

/**
 * Dirron Parkour 2: 6 локаций по 15 комнат, «Разлом» 91–99, финал 100.
 * Проверки строже, чем у первой карты:
 * <ul>
 *   <li>прыжок с песка душ и под потолком — короче обычного;</li>
 *   <li>на пути каждого прыжка (от края до края, на высоте тела и головы)
 *       нет ни одного блока — ни окружения, ни соседних ступеней;</li>
 *   <li>финиш достижим только по таким честным прыжкам и лестницам;</li>
 *   <li>окружение не ближе 3 блоков над любой платформой и не на пути.</li>
 * </ul>
 */
class SecondMapTest {
    static final int BX = 0, BY = 100, BZ = 0;
    static final RoomPlan[] ROOMS = new RoomPlan[ParkourLayout.ROOMS + 1];

    static RoomPlan room(int n) {
        if (ROOMS[n] == null) ROOMS[n] = ParkourLayout.plan(2, BX, BY, BZ, n);
        return ROOMS[n];
    }

    static String top(RoomPlan plan, Platform p) {
        String b = plan.blueprint.get((p.x0() + p.x1()) / 2, p.y(), (p.z0() + p.z1()) / 2);
        return b == null ? "" : b;
    }

    /** Есть ли потолок над платформой (прыжок «под потолком»). */
    static boolean ceiling(RoomPlan plan, Platform p) {
        for (int x = p.x0(); x <= p.x1(); x++)
            for (int z = p.z0(); z <= p.z1(); z++)
                if (plan.blueprint.has(x, p.y() + 3, z)) return true;
        return false;
    }

    /** Строгий прыжок a → b. */
    static boolean strictJump(RoomPlan plan, Platform a, Platform b) {
        double gap = a.airGapTo(b);
        int dy = b.y() - a.y();
        if (top(plan, a).contains("soul_sand")) return dy <= 0 ? gap <= 2.5 : dy == 1 && gap <= 1.2;
        if (ceiling(plan, a)) return dy <= 0 && dy >= -4 && gap <= 2.5;
        if (a.kind() == Platform.Kind.BOUNCE) return dy <= 2 && gap <= 3.2;
        if (a.kind() == Platform.Kind.RUNWAY && dy == 0 && gap <= 4.0) return true;
        if (dy > 1) return false;
        if (dy == 1) return gap <= 2.25;
        if (dy >= -6) return gap <= 3.2;
        return false;
    }

    static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    /**
     * Блоки на пути прыжка: отрезок между ближайшими точками краёв, высота
     * от уровня ног до головы в верхней точке. Платформы a и b — не помеха.
     */
    static List<String> blockers(RoomPlan plan, Platform a, Platform b) {
        double ax = clamp(b.centerX(), a.x0(), a.x1() + 1), az = clamp(b.centerZ(), a.z0(), a.z1() + 1);
        double bx = clamp(a.centerX(), b.x0(), b.x1() + 1), bz = clamp(a.centerZ(), b.z0(), b.z1() + 1);
        int y0 = Math.min(a.y(), b.y()) + 1, y1 = Math.max(a.y(), b.y()) + 2;
        List<String> out = new ArrayList<>();
        Set<Long> seen = new HashSet<>();
        for (int i = 0; i <= 20; i++) {
            double t = i / 20.0;
            int x = (int) Math.floor(ax + (bx - ax) * t), z = (int) Math.floor(az + (bz - az) * t);
            for (int y = y0; y <= y1; y++) {
                if (!seen.add(Blueprint.key(x, y, z))) continue;
                String block = plan.blueprint.get(x, y, z);
                if (block == null || block.contains("ladder") || block.contains("chain") || block.contains("vine")) continue;
                if (inside(a, x, y, z) || inside(b, x, y, z)) continue;
                out.add(block + " @" + x + "," + y + "," + z);
            }
        }
        return out;
    }

    /** Сама платформа (верх, края и подсветка под ней) — не помеха. */
    static boolean inside(Platform p, int x, int y, int z) {
        return y <= p.y() && x >= p.x0() && x <= p.x1() && z >= p.z0() && z <= p.z1();
    }

    static boolean step(RoomPlan plan, Platform a, Platform b) {
        return (strictJump(plan, a, b) && blockers(plan, a, b).isEmpty()) || MapGeneratorTest.canClimb(plan, a, b);
    }

    static boolean finishReachable(RoomPlan plan) {
        List<Platform> ps = plan.platforms;
        Set<Integer> seen = new HashSet<>(List.of(0));
        ArrayDeque<Integer> queue = new ArrayDeque<>(List.of(0));
        while (!queue.isEmpty()) {
            Platform a = ps.get(queue.poll());
            if (a.kind() == Platform.Kind.FINISH) return true;
            for (Platform b : ps) {
                if (!seen.contains(b.index()) && step(plan, a, b)) {
                    seen.add(b.index());
                    queue.add(b.index());
                }
            }
        }
        return false;
    }

    @Test
    void locationsEvery15RoomsThenRiftAndFinale() {
        Theme[] expect = {Theme.FOREST, Theme.MOUNTAIN, Theme.DESERT, Theme.REEF, Theme.NETHER, Theme.END_ISLES};
        for (int n = 1; n <= 90; n++) assertEquals(expect[(n - 1) / 15], room(n).theme, "комната " + n);
        for (int n = 91; n <= 99; n++) assertEquals(Theme.RIFT, room(n).theme, "комната " + n);
        assertEquals(Theme.ARENA, room(100).theme);
    }

    @Test
    void everyRoomIsCompletableByStrictJumps() {
        for (int n = 1; n <= 100; n++) {
            RoomPlan plan = room(n);
            assertEquals(Platform.Kind.START, plan.start().kind(), "комната " + n);
            assertEquals(Platform.Kind.FINISH, plan.finish().kind(), "комната " + n);
            assertTrue(plan.platforms.size() >= 8, "комната " + n + ": слишком короткая");
            assertTrue(finishReachable(plan), "комната " + n + " (" + plan.theme.title + "): финиш недостижим честными прыжками");
        }
    }

    /** Каждый следующий шаг маршрута — честный прыжок (или лестница) прямо с предыдущего. */
    @Test
    void routeStepsInOrderAreClear() {
        List<String> bad = new ArrayList<>();
        for (int n = 1; n <= 99; n++) {
            RoomPlan plan = room(n);
            List<Platform> ps = plan.platforms;
            for (int i = 1; i < ps.size(); i++) {
                Platform b = ps.get(i);
                boolean ok = false;
                // Шаг доступен хотя бы с одной из предыдущих платформ (развилки сходятся).
                for (int j = i - 1; j >= Math.max(0, i - 4) && !ok; j--) ok = step(plan, ps.get(j), b);
                if (!ok) {
                    Platform a = ps.get(i - 1);
                    bad.add("комната " + n + ": " + (i - 1) + "→" + i + " щель " + Math.round(a.airGapTo(b) * 100) / 100.0
                            + " dy " + (b.y() - a.y()) + " " + blockers(plan, a, b));
                }
            }
        }
        assertTrue(bad.isEmpty(), bad.size() + " неудобных шагов:\n" + String.join("\n", bad.subList(0, Math.min(25, bad.size()))));
    }

    @Test
    void headroomAndSceneryKeepAway() {
        for (int n = 1; n <= 100; n++) {
            RoomPlan plan = room(n);
            for (Platform p : plan.platforms) {
                for (int x = p.x0(); x <= p.x1(); x++) {
                    for (int z = p.z0(); z <= p.z1(); z++) {
                        for (int dy = 1; dy <= 2; dy++) {
                            String above = plan.blueprint.get(x, p.y() + dy, z);
                            assertTrue(above == null || above.contains("chain") || above.contains("ladder"),
                                    "комната " + n + ": над платформой " + p.index() + " блок " + above);
                        }
                        for (int dy = 1; dy <= 4; dy++) {
                            assertFalse(plan.decor.contains(Blueprint.key(x, p.y() + dy, z)),
                                    "комната " + n + ": окружение над платформой " + p.index());
                        }
                    }
                }
            }
            // Окружение ниже всей трассы или далеко в стороне от неё.
            int lowest = plan.platforms.stream().mapToInt(Platform::y).min().orElse(BY);
            for (long k : plan.decor) {
                int x = Blueprint.keyX(k), y = Blueprint.keyY(k), z = Blueprint.keyZ(k);
                if (y < lowest - 2) continue;
                for (Platform p : plan.platforms) {
                    double dx = Math.max(0, Math.max(p.x0() - x, x - p.x1()));
                    double dz = Math.max(0, Math.max(p.z0() - z, z - p.z1()));
                    assertTrue(Math.hypot(dx, dz) >= 3 || y < p.y() - 2,
                            "комната " + n + ": окружение " + plan.blueprint.get(x, y, z) + " рядом с платформой " + p.index());
                }
            }
        }
    }

    @Test
    void actionPointsAndCellSize() {
        for (int n = 1; n <= 100; n++) {
            RoomPlan plan = room(n);
            assertFalse(plan.bridge.isEmpty(), "комната " + n + ": нет разрыва для «Моста»");
            assertTrue(plan.shortcut.size() >= 3, "комната " + n + ": нет «Срезки»");
            assertTrue(plan.vanishCandidates.size() >= 4, "комната " + n + ": мало ступеней для «Исчезающей»");
            assertTrue(plan.maxX - plan.minX < ParkourLayout.SPACING - 4, "комната " + n + " шире ячейки");
            assertTrue(plan.maxZ - plan.minZ < ParkourLayout.SPACING - 4, "комната " + n + " глубже ячейки");
            assertTrue(plan.fallY < plan.start().y());
            for (int[] b : plan.bridge) assertFalse(plan.blueprint.has(b[0], b[1], b[2]));
            for (int[] s : plan.shortcut) assertFalse(plan.blueprint.has(s[0], s[1], s[2]));
        }
    }

    @Test
    void differentFromFirstMapAndFromEachOther() {
        Set<String> shapes = new HashSet<>();
        for (int n = 1; n <= 99; n++) {
            String shape = shape(room(n));
            shapes.add(shape);
            assertNotEquals(shape(ParkourLayout.plan(1, BX, BY, BZ, n)), shape, "комната " + n + " как в первой карте");
        }
        assertEquals(99, shapes.size(), "одинаковые комнаты");
    }

    static String shape(RoomPlan plan) {
        Platform s = plan.platforms.get(0);
        StringBuilder sb = new StringBuilder();
        for (Platform p : plan.platforms) sb.append(p.x0() - s.x0()).append(',').append(p.z0() - s.z0()).append(',').append(p.y() - s.y()).append(';');
        return sb.toString();
    }

    @Test
    void difficultyGrowsAndRiftIsHardest() {
        int introSmall = 0, lateSmall = 0;
        double introLen = 0, riftLen = 0;
        for (int n = 1; n <= 99; n++) {
            RoomPlan plan = room(n);
            for (Platform p : plan.platforms) {
                boolean small = p.x0() == p.x1() && p.z0() == p.z1();
                if (n <= 5 && small) introSmall++;
                if (n > 60 && small) lateSmall++;
            }
            if (n <= 15) introLen += plan.platforms.size() / 15.0;
            if (n >= 91) riftLen += plan.platforms.size() / 9.0;
        }
        assertEquals(0, introSmall, "в разминке (1–5) нет площадок 1×1");
        assertTrue(lateSmall > 150, "много точных приземлений в конце: " + lateSmall);
        assertTrue(riftLen > introLen * 1.5, "«Разлом» длиннее и сложнее начала: " + riftLen + " против " + introLen);
    }

    /** Вторая часть сложнее первой в каждой десятке уровней. */
    @Test
    void harderThanFirstMapInEveryTen() {
        int total1 = 0, total2 = 0, small1 = 0, small2 = 0;
        for (int g = 0; g < 10; g++) {
            int jumps1 = 0, jumps2 = 0, s1 = 0, s2 = 0;
            for (int n = g * 10 + 1; n <= g * 10 + 10 && n < 100; n++) {
                RoomPlan a = ParkourLayout.plan(1, BX, BY, BZ, n);
                RoomPlan b = room(n);
                jumps1 += a.platforms.size();
                jumps2 += b.platforms.size();
                for (Platform p : a.platforms) if (p.x0() == p.x1() && p.z0() == p.z1()) s1++;
                for (Platform p : b.platforms) if (p.x0() == p.x1() && p.z0() == p.z1()) s2++;
            }
            String range = (g * 10 + 1) + "–" + (g * 10 + 10);
            assertTrue(jumps2 > jumps1, "уровни " + range + ": прыжков во второй части больше (" + jumps2 + " против " + jumps1 + ")");
            assertTrue(s2 > s1,
                    "уровни " + range + ": площадок 1×1 больше (" + s2 + " против " + s1 + ")");
            total1 += jumps1; total2 += jumps2; small1 += s1; small2 += s2;
        }
        assertTrue(total2 > total1 * 1.25, "всего прыжков заметно больше: " + total2 + " против " + total1);
        assertTrue(small2 > small1 * 1.3, "всего точных приземлений заметно больше: " + small2 + " против " + small1);
    }

    @Test
    void blocksAreKnown() {
        for (int n = 1; n <= 100; n++) {
            for (String b : room(n).blueprint.blocks().values()) {
                assertTrue(b.matches("minecraft:[a-z_]+(\\[[a-z_]+=[a-z0-9_]+(,[a-z_]+=[a-z0-9_]+)*])?"), b);
            }
        }
    }

    /** С любой платформы, куда можно попасть, путь к финишу продолжается — тупиков нет. */
    @Test
    void noDeadEnds() {
        for (int n = 1; n <= 100; n++) {
            RoomPlan plan = room(n);
            List<Platform> ps = plan.platforms;
            Set<Integer> reach = new HashSet<>(List.of(0));
            ArrayDeque<Integer> q = new ArrayDeque<>(List.of(0));
            while (!q.isEmpty()) {
                Platform a = ps.get(q.poll());
                for (Platform b : ps) if (!reach.contains(b.index()) && step(plan, a, b)) { reach.add(b.index()); q.add(b.index()); }
            }
            for (int from : reach) {
                Set<Integer> seen = new HashSet<>(List.of(from));
                ArrayDeque<Integer> w = new ArrayDeque<>(List.of(from));
                boolean ok = false;
                while (!w.isEmpty() && !ok) {
                    Platform a = ps.get(w.poll());
                    if (a.kind() == Platform.Kind.FINISH) ok = true;
                    for (Platform b : ps) if (!seen.contains(b.index()) && step(plan, a, b)) { seen.add(b.index()); w.add(b.index()); }
                }
                assertTrue(ok, "комната " + n + ": с платформы " + from + " нельзя дойти до финиша (тупик)");
            }
        }
    }
}
