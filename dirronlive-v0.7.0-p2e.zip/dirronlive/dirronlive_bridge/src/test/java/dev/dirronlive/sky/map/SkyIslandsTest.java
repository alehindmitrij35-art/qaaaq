package dev.dirronlive.sky.map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import dev.dirronlive.parkour.map.Blueprint;
import dev.dirronlive.sky.core.FlightAssist;
import dev.dirronlive.sky.core.Forces;
import dev.dirronlive.sky.core.Ring;
import dev.dirronlive.sky.core.Sector;
import dev.dirronlive.sky.core.SkyRun;
import dev.dirronlive.sky.core.Track;
import dev.dirronlive.sky.core.V3;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;

/**
 * Карта «Небесные острова»: трасса по правилам, острова не мешают полёту, и
 * трассу можно пролететь на элитрах по настоящей физике Minecraft 1.21.1
 * (простым автопилотом, без фейерверков).
 */
class SkyIslandsTest {
    static final SkyIslands.Layout L = SkyIslands.generate(0, 0, 0);

    @Test
    void trackFollowsTheRules() {
        Track t = L.track();
        assertEquals(List.of(), t.problems());
        assertEquals(6, t.sectors.size());
        for (Sector s : t.sectors) {
            assertTrue(s.rings().size() >= 6 && s.rings().size() <= 8, "сектор " + s.index());
            assertEquals(1, s.rings().stream().filter(Ring::isBoost).count(), "одно ускоряющее кольцо в секторе");
        }
        assertEquals(6, t.zones.size(), "восходящий поток в каждом секторе");
        assertEquals(6, t.training.size());
        assertEquals(Ring.Kind.FINISH, t.rings.get(t.ringCount() - 1).kind());
        // Трасса переживает сохранение в JSON.
        Track back = Track.fromJson(t.toJson());
        assertEquals(t.ringCount(), back.ringCount());
        assertEquals(List.of(), back.problems());
    }

    @Test
    void ringsGetSmallerSectorBySector() {
        List<Sector> s = L.track().sectors;
        assertTrue(s.get(0).rings().get(0).radius() > s.get(5).rings().get(0).radius());
        assertTrue(s.get(5).rings().get(0).radius() >= 3.4);
    }

    @Test
    void islandsKeepTheFlightPathClear() {
        Blueprint bp = L.blueprint();
        assertTrue(bp.size() > 15_000 && bp.size() < 250_000, "блоков: " + bp.size());
        int bad = 0;
        for (Long k : bp.blocks().keySet()) {
            V3 p = new V3(Blueprint.keyX(k) + 0.5, Blueprint.keyY(k) + 0.5, Blueprint.keyZ(k) + 0.5);
            for (V3[] seg : L.path()) {
                if (SkyIslands.distanceToSegment(p, seg[0], seg[1]) < seg[2].x() + 2.5) bad++;
            }
        }
        assertEquals(0, bad);
    }

    @Test
    void everyBlockIsKnownStyle() {
        for (Map.Entry<Long, String> e : L.blueprint().blocks().entrySet()) {
            assertTrue(e.getValue().matches("minecraft:[a-z_]+(\\[[a-z_]+=[a-z0-9_]+(,[a-z_]+=[a-z0-9_]+)*])?"), e.getValue());
        }
    }

    // --------------------------------------------------------------- полёт

    /** Физика элитр из LivingEntity.travel (1.21.1). */
    static V3 elytra(V3 v, float yaw, float pitch) {
        V3 look = V3.look(yaw, pitch);
        double f = Math.toRadians(pitch);
        double i = Math.sqrt(look.x() * look.x() + look.z() * look.z());
        double j = v.horizontal();
        double k = look.length();
        double l = Math.cos(f);
        l = l * l * Math.min(1.0, k / 0.4);
        v = v.add(0, 0.08 * (-1.0 + l * 0.75), 0);
        if (v.y() < 0 && i > 0) {
            double m = v.y() * -0.1 * l;
            v = v.add(look.x() * m / i, m, look.z() * m / i);
        }
        if (f < 0 && i > 0) {
            double m = j * -Math.sin(f) * 0.04;
            v = v.add(-look.x() * m / i, m * 3.2, -look.z() * m / i);
        }
        if (i > 0) v = v.add((look.x() / i * j - v.x()) * 0.1, 0, (look.z() / i * j - v.z()) * 0.1);
        return new V3(v.x() * 0.99, v.y() * 0.98, v.z() * 0.99);
    }

    /**
     * Простой пилот: курс на центр следующего кольца, медленнее 1.15 блока/тик —
     * пикировать; в восходящем потоке — ровно, поток поднимает сам.
     */
    static float[] pilot(Track t, V3 pos, V3 vel, V3 target) {
        V3 to = target.sub(pos);
        float yaw = V3.angles(to)[0];
        double climb = Math.toDegrees(Math.atan2(to.y(), Math.max(1, to.horizontal())));
        boolean lift = t.zonesAt(pos).stream().anyMatch(z -> z.contains(pos));
        double speed = vel.length();
        double pitch = (lift ? 0 : -climb * 1.6) + (1.15 - speed) * 35;
        return new float[] {yaw, (float) Math.max(-50, Math.min(50, pitch))};
    }

    record Flight(SkyRun run, int returns, long ticks, double lowest) {}

    static Flight fly(Track t, Blueprint bp, int limit) {
        SkyRun run = new SkyRun(t);
        run.start();
        for (int i = 0; i < SkyRun.COUNTDOWN_TICKS; i++) run.tick(new SkyRun.Sample(null, null, true, false, false));
        V3 pos = run.checkpoint().pos();
        V3 vel = run.checkpoint().velocity();
        int returns = 0;
        double lowest = 1e9;
        boolean teleported = true;
        long tick = 0;
        while (run.phase() == SkyRun.Phase.RUNNING && tick < limit) {
            tick++;
            int n = Math.min(run.nextRing(), t.ringCount() - 1);
            float[] a = pilot(t, pos, vel, t.rings.get(n).center());
            vel = elytra(vel, a[0], a[1]);
            V3 next = pos.add(vel);
            vel = FlightAssist.adjust(next, vel, t.zonesAt(next), t.speedCap, Forces.NONE, tick);
            boolean hit = bp != null && bp.has((int) Math.floor(next.x()), (int) Math.floor(next.y()), (int) Math.floor(next.z()));
            List<SkyRun.Event> ev = run.tick(new SkyRun.Sample(pos, next, teleported, false, hit));
            teleported = false;
            pos = next;
            lowest = Math.min(lowest, pos.y());
            for (SkyRun.Event e : ev) {
                if (e.type() == SkyRun.EventType.RETURN) {
                    returns++;
                    pos = run.checkpoint().pos();
                    vel = run.checkpoint().velocity();
                    teleported = true;
                }
            }
        }
        return new Flight(run, returns, tick, lowest);
    }

    @Test
    void wholeTrackIsFlyableWithoutFireworks() {
        Flight f = fly(L.track(), L.blueprint(), 20 * 60 * 6);
        SkyRun run = f.run();
        assertEquals(SkyRun.Phase.FINISHED, run.phase(),
                "застрял: кольцо " + run.nextRing() + ", возвратов " + f.returns() + ", промахов " + run.misses());
        assertEquals(0, f.returns(), "без падений и столкновений");
        assertEquals(0, run.misses(), "автопилот проходит все кольца");
        double seconds = f.ticks() / 20.0;
        assertTrue(seconds > 40 && seconds < 240, "время заезда " + seconds + " с");
        System.out.println("SKY_SIM финиш за " + seconds + " с, ниже всего y=" + Math.round(f.lowest()));
    }

    @Test
    void everySectorIsFlyableFromItsCheckpoint() {
        Track t = L.track();
        for (Sector s : t.sectors) {
            // Лететь от контрольной точки сектора до его последнего кольца.
            V3 pos = s.checkpoint().pos();
            V3 vel = s.checkpoint().velocity();
            int next = s.first();
            for (int tick = 0; tick < 20 * 60 && next <= s.last(); tick++) {
                float[] a = pilot(t, pos, vel, t.rings.get(next).center());
                vel = elytra(vel, a[0], a[1]);
                V3 np = pos.add(vel);
                vel = FlightAssist.adjust(np, vel, t.zonesAt(np), t.speedCap, Forces.NONE, tick);
                if (dev.dirronlive.sky.core.RingCheck.cross(pos, np, t.rings.get(next)) == dev.dirronlive.sky.core.RingCheck.Result.HIT) next++;
                pos = np;
                assertTrue(pos.y() > t.minY, "сектор " + (s.index() + 1) + ": упал, ждали кольцо " + (next + 1)
                        + " (y=" + Math.round(t.rings.get(Math.min(next, s.last())).center().y()) + ")");
            }
            assertEquals(s.last() + 1, next, "сектор " + (s.index() + 1) + " с контрольной точки");
        }
    }

    @Test
    void trainingLoopIsFlyable() {
        Track tt = dev.dirronlive.sky.core.Track.fromJson(L.track().toJson());
        List<Ring> tr = tt.training;
        V3 pos = tt.trainingStart.pos();
        V3 vel = tt.trainingStart.velocity();
        int next = 0;
        for (int tick = 0; tick < 20 * 60 && next < tr.size(); tick++) {
            float[] a = pilot(tt, pos, vel, tr.get(next).center());
            vel = elytra(vel, a[0], a[1]);
            V3 np = pos.add(vel);
            if (dev.dirronlive.sky.core.RingCheck.cross(pos, np, tr.get(next)) == dev.dirronlive.sky.core.RingCheck.Result.HIT) next++;
            pos = np;
        }
        assertEquals(tr.size(), next, "тренировочный круг");
    }
}
