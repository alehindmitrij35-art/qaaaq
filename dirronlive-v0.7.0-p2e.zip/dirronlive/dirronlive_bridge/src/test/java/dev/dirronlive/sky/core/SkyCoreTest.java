package dev.dirronlive.sky.core;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;

/** Кольца, сектора, ошибки, пауза и трасса в JSON — без Minecraft. */
class SkyCoreTest {
    static final V3 Z = new V3(0, 0, 1);

    /** Два сектора по 3 кольца вдоль +Z, каждые 20 блоков; последнее — финиш. */
    static Track line(Track.OnMiss onMiss) {
        List<Sector> sectors = new ArrayList<>();
        int order = 0;
        for (int s = 0; s < 2; s++) {
            List<Ring> rings = new ArrayList<>();
            for (int i = 0; i < 3; i++) {
                boolean last = s == 1 && i == 2;
                Ring.Kind kind = last ? Ring.Kind.FINISH : (s == 0 && i == 1 ? Ring.Kind.BOOST : Ring.Kind.NORMAL);
                rings.add(new Ring(order, s, new V3(0, 100, 20 + order * 20), Z, 4, kind, kind == Ring.Kind.BOOST ? 1.6 : 0));
                order++;
            }
            sectors.add(new Sector(s, "Сектор " + (s + 1), Checkpoint.before(rings.get(0), 10, 0, 0.8), rings));
        }
        return new Track("test", "Тест", 1, sectors, List.of(new Zone(Zone.Kind.LIFT, new V3(-5, 90, 0), new V3(5, 110, 8), 0.1)),
                new Track.Spot(new V3(0, 101, -20), 0), null, null, null,
                new V3(-200, 0, -200), new V3(200, 300, 300), 50, 2.4, 60, onMiss);
    }

    static SkyRun.Sample fly(V3 a, V3 b) {
        return new SkyRun.Sample(a, b, false, false, false);
    }

    static SkyRun launched(Track t) {
        SkyRun run = new SkyRun(t);
        run.start();
        for (int i = 0; i < SkyRun.COUNTDOWN_TICKS; i++) run.tick(fly(null, null));
        assertEquals(SkyRun.Phase.RUNNING, run.phase());
        return run;
    }

    /** Лететь по оси от z0 до z1 шагами по 3 блока, собрать события. */
    static List<SkyRun.Event> flyLine(SkyRun run, double x, double z0, double z1) {
        List<SkyRun.Event> all = new ArrayList<>();
        double step = z1 > z0 ? 3 : -3;
        for (double z = z0; (step > 0 ? z < z1 : z > z1); z += step) {
            all.addAll(run.tick(fly(new V3(x, 100, z), new V3(x, 100, z + step))));
        }
        return all;
    }

    static long count(List<SkyRun.Event> events, SkyRun.EventType type) {
        return events.stream().filter(e -> e.type() == type).count();
    }

    @Test
    void fastSegmentThroughCenterIsHit() {
        Ring r = new Ring(0, 0, new V3(0, 100, 50), Z, 3, Ring.Kind.NORMAL, 0);
        // 5 блоков за тик: обе точки вне кольца, отрезок — через него.
        assertEquals(RingCheck.Result.HIT, RingCheck.cross(new V3(0, 100, 47.5), new V3(0.5, 100.2, 52.5), r));
    }

    @Test
    void directionMatters() {
        Ring r = new Ring(0, 0, new V3(0, 100, 50), Z, 3, Ring.Kind.NORMAL, 0);
        assertEquals(RingCheck.Result.BACKWARD, RingCheck.cross(new V3(0, 100, 52), new V3(0, 100, 48), r));
    }

    @Test
    void segmentStartingOnPlaneIsNotCountedAgain() {
        Ring r = new Ring(0, 0, new V3(0, 100, 50), Z, 3, Ring.Kind.NORMAL, 0);
        assertEquals(RingCheck.Result.HIT, RingCheck.cross(new V3(0, 100, 48), new V3(0, 100, 50), r));
        assertEquals(RingCheck.Result.NONE, RingCheck.cross(new V3(0, 100, 50), new V3(0, 100, 52), r));
    }

    @Test
    void besideRingIsMissFarAwayIsNothing() {
        Ring r = new Ring(0, 0, new V3(0, 100, 50), Z, 3, Ring.Kind.NORMAL, 0);
        assertEquals(RingCheck.Result.MISS, RingCheck.cross(new V3(5, 100, 49), new V3(5, 100, 51), r));
        assertEquals(RingCheck.Result.NONE, RingCheck.cross(new V3(30, 100, 49), new V3(30, 100, 51), r));
    }

    @Test
    void tiltedRingUsesItsNormal() {
        V3 n = new V3(1, 0, 1).normalize();
        Ring r = new Ring(0, 0, new V3(10, 100, 10), n, 3, Ring.Kind.NORMAL, 0);
        assertEquals(RingCheck.Result.HIT, RingCheck.cross(new V3(8, 100, 8), new V3(12, 100, 12), r));
        assertEquals(RingCheck.Result.NONE, RingCheck.cross(new V3(8, 100, 12), new V3(12, 100, 8), r), "вдоль плоскости");
    }

    @Test
    void countdownThenLaunch() {
        SkyRun run = new SkyRun(line(Track.OnMiss.ERROR));
        List<SkyRun.Event> e = new ArrayList<>(run.start());
        for (int i = 0; i < SkyRun.COUNTDOWN_TICKS; i++) e.addAll(run.tick(fly(null, null)));
        assertEquals(List.of(3, 2, 1), e.stream().filter(x -> x.type() == SkyRun.EventType.COUNTDOWN).map(SkyRun.Event::value).toList());
        assertEquals(SkyRun.EventType.LAUNCH, e.get(e.size() - 1).type());
        assertEquals(0, run.ticks(), "отсчёт не входит во время");
        assertEquals(60, run.protection());
    }

    @Test
    void fullRunSectorsAndFinish() {
        Track t = line(Track.OnMiss.ERROR);
        SkyRun run = launched(t);
        List<SkyRun.Event> e = flyLine(run, 0.5, 5, 140);
        assertEquals(6, count(e, SkyRun.EventType.RING) + count(e, SkyRun.EventType.BOOST));
        assertEquals(1, count(e, SkyRun.EventType.BOOST));
        assertEquals(1, count(e, SkyRun.EventType.SECTOR));
        assertEquals(1, count(e, SkyRun.EventType.FINISH));
        assertEquals(SkyRun.Phase.FINISHED, run.phase());
        assertEquals(0, run.errors());
        assertTrue(run.ticks() > 0 && run.bestTicks() == run.ticks());
    }

    @Test
    void ringNeverCountsTwice() {
        SkyRun run = launched(line(Track.OnMiss.ERROR));
        flyLine(run, 0, 5, 30);           // через кольцо 1 (z=20)
        assertEquals(1, run.nextRing());
        List<SkyRun.Event> back = flyLine(run, 0, 30, 10); // назад через то же кольцо
        assertEquals(0, count(back, SkyRun.EventType.RING));
        List<SkyRun.Event> again = flyLine(run, 0, 10, 30); // и снова вперёд
        assertEquals(0, count(again, SkyRun.EventType.RING));
        assertEquals(1, run.nextRing());
    }

    @Test
    void skippedRingIsMissAndNextCounts() {
        SkyRun run = launched(line(Track.OnMiss.ERROR));
        // Кольцо 1 облетаем далеко сбоку, кольцо 2 проходим.
        List<SkyRun.Event> e = new ArrayList<>(flyLine(run, 30, 5, 26));
        V3 p = new V3(30, 100, 26);
        for (int i = 1; i <= 10; i++) {
            V3 q = new V3(30 - 3 * i, 100, 26 + 1.2 * i);
            e.addAll(run.tick(fly(p, q)));
            p = q;
        }
        e.addAll(flyLine(run, 0, 38, 45));
        assertEquals(1, count(e, SkyRun.EventType.MISS));
        assertEquals(1, count(e, SkyRun.EventType.BOOST));
        assertEquals(2, run.nextRing());
        assertEquals(1, run.misses());
    }

    @Test
    void missNearRingCountsError() {
        SkyRun run = launched(line(Track.OnMiss.ERROR));
        List<SkyRun.Event> e = flyLine(run, 7, 5, 30);
        assertEquals(1, count(e, SkyRun.EventType.MISS));
        assertEquals(1, run.nextRing());
        assertEquals(SkyRun.Phase.RUNNING, run.phase());
    }

    @Test
    void missCanReturnToCheckpoint() {
        SkyRun run = launched(line(Track.OnMiss.CHECKPOINT));
        List<SkyRun.Event> e = flyLine(run, 7, 5, 30);
        assertEquals(1, count(e, SkyRun.EventType.RETURN));
        assertEquals(0, run.nextRing(), "кольцо нужно пройти заново");
    }

    @Test
    void crashAfterProtectionReturnsToSectorCheckpoint() {
        Track t = line(Track.OnMiss.ERROR);
        SkyRun run = launched(t);
        flyLine(run, 0, 5, 90); // сектор 2
        assertEquals(1, run.sector());
        // защита уже прошла (30 тиков полёта > 0? нет — проверим явно)
        while (run.protection() > 0) run.tick(fly(new V3(0, 100, 90), new V3(0, 100, 90.5)));
        List<SkyRun.Event> e = run.tick(new SkyRun.Sample(new V3(0, 100, 91), new V3(0, 100, 91.2), false, false, true));
        assertEquals(SkyRun.EventType.RETURN, e.get(0).type());
        assertEquals(1, e.get(0).value());
        assertEquals("crash", e.get(0).reason());
        assertEquals(1, run.crashes());
        assertEquals(t.sectors.get(1).checkpoint(), run.checkpoint());
        // Сразу после возврата — 3 секунды защиты: касание земли без штрафа.
        assertTrue(run.tick(new SkyRun.Sample(null, null, true, true, false)).isEmpty());
        assertEquals(1, run.crashes());
    }

    @Test
    void voidAlwaysReturnsButPenaltyOnlyOnce() {
        SkyRun run = launched(line(Track.OnMiss.ERROR));
        List<SkyRun.Event> e = run.tick(fly(new V3(0, 60, 5), new V3(0, 40, 6)));
        assertEquals("void", e.get(0).reason());
        assertEquals(0, run.crashes(), "в защите после старта штрафа нет");
    }

    @Test
    void teleportStepIgnored() {
        SkyRun run = launched(line(Track.OnMiss.ERROR));
        run.tick(fly(new V3(0, 100, 0), new V3(0, 100, 30)));
        assertEquals(0, run.nextRing());
    }

    @Test
    void pauseFreezesTimeAndResumeCountsDown() {
        SkyRun run = launched(line(Track.OnMiss.ERROR));
        flyLine(run, 0, 5, 14);
        long t = run.ticks();
        assertTrue(run.pause());
        for (int i = 0; i < 100; i++) run.tick(fly(new V3(0, 100, 14), new V3(0, 100, 14)));
        assertEquals(t, run.ticks());
        assertEquals(SkyRun.Phase.PAUSED, run.phase());
        List<SkyRun.Event> e = new ArrayList<>(run.resume());
        for (int i = 0; i < SkyRun.COUNTDOWN_TICKS; i++) e.addAll(run.tick(fly(null, null)));
        assertEquals(SkyRun.EventType.RESUME, e.get(e.size() - 1).type());
        assertEquals(SkyRun.Phase.RUNNING, run.phase());
        assertEquals(t, run.ticks());
    }

    @Test
    void restartResetsEverything() {
        SkyRun run = launched(line(Track.OnMiss.ERROR));
        flyLine(run, 7, 5, 30);
        assertEquals(1, run.errors());
        run.start();
        assertEquals(0, run.errors());
        assertEquals(0, run.nextRing());
        assertEquals(SkyRun.Phase.COUNTDOWN, run.phase());
    }

    @Test
    void trackJsonRoundTrip() {
        Track t = line(Track.OnMiss.CHECKPOINT);
        assertEquals(List.of(), t.problems());
        Track back = Track.fromJson(t.toJson());
        assertEquals(t.ringCount(), back.ringCount());
        assertEquals(t.rings.get(4).center(), back.rings.get(4).center());
        assertEquals(Ring.Kind.BOOST, back.rings.get(1).kind());
        assertEquals(Track.OnMiss.CHECKPOINT, back.onMiss);
        assertEquals(60, back.protectionTicks);
        assertEquals(1, back.zones.size());
        assertEquals(List.of(), back.problems());
    }

    @Test
    void problemsAreReported() {
        Ring r = new Ring(0, 0, new V3(0, 100, 20), Z, 4, Ring.Kind.NORMAL, 0);
        // контрольная точка за кольцом
        Sector s = new Sector(0, "S", new Checkpoint(new V3(0, 100, 40), 0, 0, 0.8), List.of(r));
        Track t = new Track("x", "x", 1, List.of(s), List.of(), new Track.Spot(V3.ZERO, 0), null, null, null,
                new V3(-50, 0, -50), new V3(50, 200, 50), 10, 2.4, 60, Track.OnMiss.ERROR);
        List<String> p = t.problems();
        assertTrue(p.stream().anyMatch(x -> x.contains("не перед первым")), p.toString());
        assertTrue(p.stream().anyMatch(x -> x.contains("финишное")), p.toString());
    }

    @Test
    void flightAssistCapLiftAndForces() {
        Track t = line(Track.OnMiss.ERROR);
        V3 fast = new V3(0, 0, 5);
        V3 capped = FlightAssist.adjust(new V3(100, 100, 100), fast, List.of(), t.speedCap, Forces.NONE, 0);
        assertEquals(2.4, capped.length(), 1e-9);
        V3 slow = new V3(0, -0.2, 1);
        assertSame(slow, FlightAssist.adjust(new V3(100, 100, 100), slow, List.of(), 2.4, Forces.NONE, 0));
        V3 lifted = FlightAssist.adjust(new V3(0, 100, 4), slow, t.zonesAt(new V3(0, 100, 4)), 2.4, Forces.NONE, 0);
        assertEquals(-0.1, lifted.y(), 1e-9);
        Forces wind = new Forces(new V3(0.05, 0, 0), 0, 0, 1, 0, 1);
        assertEquals(0.05, FlightAssist.adjust(V3.ZERO, slow, List.of(), 2.4, wind, 0).x(), 1e-9);
        Forces brake = new Forces(V3.ZERO, 0, 0, 0.9, 0, 0.5);
        V3 b = FlightAssist.adjust(V3.ZERO, new V3(0, 0, 2), List.of(), 2.4, brake, 0);
        assertEquals(1.2, b.length(), 1e-9, "предел скорости ×0.5");
    }

    @Test
    void anglesMatchMinecraftLook() {
        for (float yaw : new float[] {0, 45, 90, -135, 180}) {
            for (float pitch : new float[] {-30, 0, 20}) {
                V3 d = V3.look(yaw, pitch);
                float[] a = V3.angles(d);
                assertEquals(0, V3.look(a[0], a[1]).distance(d), 1e-6);
            }
        }
        V3 south = V3.look(0, 0);
        assertEquals(1, south.z(), 1e-9);
        assertFalse(south.x() > 1e-9);
    }

    @Test
    void gridFindsZones() {
        SpatialGrid<String> g = new SpatialGrid<>();
        g.add(new V3(0, 0, 0), new V3(40, 10, 10), "a");
        g.add(new V3(100, 0, 100), new V3(101, 1, 101), "b");
        assertEquals(List.of("a"), g.at(new V3(35, 5, 5)));
        assertTrue(g.at(new V3(70, 5, 5)).isEmpty());
        assertTrue(g.near(new V3(90, 0, 90), 20).contains("b"));
    }
}
