package dev.dirronlive.sky.core;

/** Точка или вектор в мире (без зависимостей от Minecraft, чтобы проверять обычными тестами). */
public record V3(double x, double y, double z) {
    public static final V3 ZERO = new V3(0, 0, 0);
    public static final V3 UP = new V3(0, 1, 0);

    public V3 add(V3 o) {
        return new V3(x + o.x, y + o.y, z + o.z);
    }

    public V3 add(double dx, double dy, double dz) {
        return new V3(x + dx, y + dy, z + dz);
    }

    public V3 sub(V3 o) {
        return new V3(x - o.x, y - o.y, z - o.z);
    }

    public V3 mul(double k) {
        return new V3(x * k, y * k, z * k);
    }

    public double dot(V3 o) {
        return x * o.x + y * o.y + z * o.z;
    }

    public V3 cross(V3 o) {
        return new V3(y * o.z - z * o.y, z * o.x - x * o.z, x * o.y - y * o.x);
    }

    public double length() {
        return Math.sqrt(x * x + y * y + z * z);
    }

    public double lengthSq() {
        return x * x + y * y + z * z;
    }

    public double horizontal() {
        return Math.sqrt(x * x + z * z);
    }

    public V3 normalize() {
        double l = length();
        return l < 1e-9 ? ZERO : mul(1 / l);
    }

    public V3 lerp(V3 o, double t) {
        return new V3(x + (o.x - x) * t, y + (o.y - y) * t, z + (o.z - z) * t);
    }

    public double distance(V3 o) {
        return sub(o).length();
    }

    /** Направление взгляда по углам Minecraft (yaw 0 — на юг, +Z). */
    public static V3 look(float yaw, float pitch) {
        double y = Math.toRadians(yaw), p = Math.toRadians(pitch);
        return new V3(-Math.sin(y) * Math.cos(p), -Math.sin(p), Math.cos(y) * Math.cos(p));
    }

    /** Углы Minecraft для направления: {yaw, pitch}. */
    public static float[] angles(V3 dir) {
        V3 d = dir.normalize();
        float yaw = (float) Math.toDegrees(Math.atan2(-d.x, d.z));
        float pitch = (float) Math.toDegrees(-Math.asin(Math.max(-1, Math.min(1, d.y))));
        return new float[] {yaw, pitch};
    }
}
