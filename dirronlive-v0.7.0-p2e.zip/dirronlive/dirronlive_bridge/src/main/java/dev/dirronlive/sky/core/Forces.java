package dev.dirronlive.sky.core;

/**
 * Силы, которые сейчас действуют на полёт (сумма активных эффектов зрителей).
 * Применяются каждый тик на стороне игрока, без пакетов с сервера.
 *
 * @param push        постоянное ускорение за тик (боковой ветер)
 * @param tailwind    ускорение за тик вдоль направления полёта (попутный поток)
 * @param sink        дополнительное снижение за тик (тяжёлые крылья)
 * @param drag        множитель скорости за тик, 1 — без торможения (воздушный тормоз)
 * @param turbulence  размах случайной тряски за тик (турбулентность)
 * @param capFactor   множитель предела скорости
 */
public record Forces(V3 push, double tailwind, double sink, double drag, double turbulence, double capFactor) {
    public static final Forces NONE = new Forces(V3.ZERO, 0, 0, 1, 0, 1);

    public boolean isNone() {
        return push.lengthSq() == 0 && tailwind == 0 && sink == 0 && drag == 1 && turbulence == 0 && capFactor == 1;
    }

    public Forces plus(Forces o) {
        return new Forces(push.add(o.push), tailwind + o.tailwind, sink + o.sink, drag * o.drag,
                turbulence + o.turbulence, capFactor * o.capFactor);
    }
}
