package dev.dirronlive.bridge;

import dev.dirronlive.parkour.world.ParkourActions;
import dev.dirronlive.parkour.world.ParkourWorld;
import java.util.UUID;
import java.util.function.Consumer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/** Всё, что мод делает внутри Minecraft. */
final class MinecraftGame implements BridgeConnection.Game {
    private volatile boolean worldReady;

    /**
     * Мир готов: запущен одиночный мир (встроенный сервер) и есть локальный
     * игрок. Вызывается каждый тик в игровом потоке.
     */
    boolean updateWorldReady(MinecraftClient client) {
        boolean ready = client.isIntegratedServerRunning()
                && client.getServer() != null
                && client.world != null
                && client.player != null;
        worldReady = ready;
        return ready;
    }

    @Override
    public boolean isWorldReady() {
        return worldReady;
    }

    @Override
    public void runOnGameThread(Runnable task) {
        MinecraftClient.getInstance().execute(task);
    }

    @Override
    public boolean showGift(BridgeProtocol.Gift gift) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (!updateWorldReady(client) || client.inGameHud == null) return false;

        // «Dirronlive • Alex отправил «Роза» ×5» над панелью быстрого доступа.
        // Серия подарков приходит сюда один раз — с итоговым количеством.
        MutableText text = Text.literal("Dirronlive").formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD)
                .append(Text.literal(" • ").formatted(Formatting.GRAY))
                .append(Text.literal(gift.viewerName()).formatted(Formatting.WHITE, Formatting.BOLD))
                .append(Text.literal(" отправил ").formatted(Formatting.GRAY))
                .append(Text.literal(gift.giftText()).formatted(Formatting.GOLD));
        client.inGameHud.setOverlayMessage(text, false);
        if (client.player != null) {
            client.player.playSound(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 0.6f, 1.4f);
        }
        return true;
    }

    @Override
    public void runAction(BridgeProtocol.Action action, Consumer<BridgeProtocol.ActionResult> done) {
        MinecraftClient client = MinecraftClient.getInstance();
        IntegratedServer server = client.getServer();
        if (!updateWorldReady(client) || server == null || client.player == null) {
            done.accept(new BridgeProtocol.ActionResult(false, "Мир не открыт — действие не выполнено", 0));
            return;
        }
        UUID uuid = client.player.getUuid();
        // Карта живёт на встроенном сервере — выполняем действие в его потоке.
        server.execute(() -> {
            try {
                ServerPlayerEntity player = server.getPlayerManager().getPlayer(uuid);
                if (player == null) {
                    done.accept(new BridgeProtocol.ActionResult(false, "Игрок ещё не вошёл в мир", 0));
                    return;
                }
                ParkourWorld pw = ParkourWorld.get(server);
                if (!pw.state.built) {
                    done.accept(new BridgeProtocol.ActionResult(false, "Это не мир Dirron Parkour", 0));
                    return;
                }
                String label = action.test() ? "Тест" : action.viewerName().isEmpty() ? action.label()
                        : action.viewerName() + (action.label().isEmpty() ? "" : " · " + action.label());
                // Очередь: одна штука = одно срабатывание, повтор total ничего не добавляет.
                pw.actions.submit(player, action.id(), action.action(), action.params(), label, action.total(),
                        p -> done.accept(new BridgeProtocol.ActionResult(p.ok() > 0 || p.done() == 0, p.result(),
                                p.room(), p.accepted(), p.done(), p.queued(), p.finished())));
            } catch (RuntimeException e) {
                done.accept(new BridgeProtocol.ActionResult(false, "Ошибка в моде: " + e.getClass().getSimpleName(), 0));
            }
        });
    }

    @Override
    public BridgeProtocol.ParkourStatus parkourStatus() {
        if (!worldReady) return new BridgeProtocol.ParkourStatus(false, 0, false, 0, 0);
        ParkourWorld.Status s = ParkourWorld.lastStatus;
        return new BridgeProtocol.ParkourStatus(s.available(), s.room(), s.finished(), s.falls(), s.ticks() / 20,
                s.roomFalls(), s.bestRoom(), s.bestTicks() / 20, s.queued());
    }

    // ------------------------------------------------------ Небесный разлом

    @Override
    public void skyCommand(BridgeProtocol.SkyCommand command, Consumer<String> reply) {
        MinecraftClient client = MinecraftClient.getInstance();
        IntegratedServer server = client.getServer();
        if (!updateWorldReady(client) || server == null || client.player == null) {
            reply.accept(BridgeProtocol.skyResult(command.id(), command.cmd(), false, "Мир не открыт"));
            return;
        }
        UUID uuid = client.player.getUuid();
        server.execute(() -> {
            try {
                ServerPlayerEntity player = server.getPlayerManager().getPlayer(uuid);
                if (player == null) {
                    reply.accept(BridgeProtocol.skyResult(command.id(), command.cmd(), false, "Игрок ещё не вошёл в мир"));
                    return;
                }
                dev.dirronlive.sky.SkyWorld.Result r = dev.dirronlive.sky.SkyWorld.get(server).command(player, command.cmd());
                reply.accept(BridgeProtocol.skyResult(command.id(), command.cmd(), r.ok(), r.text()));
            } catch (RuntimeException e) {
                reply.accept(BridgeProtocol.skyResult(command.id(), command.cmd(), false, "Ошибка в моде: " + e.getClass().getSimpleName()));
            }
        });
    }

    @Override
    public void skySettings(BridgeProtocol.SkySettings settings) {
        dev.dirronlive.sky.SkyConfig.settings = settings;
    }

    @Override
    public void skyAction(BridgeProtocol.SkyAction action, Consumer<String> reply) {
        MinecraftClient client = MinecraftClient.getInstance();
        IntegratedServer server = client.getServer();
        if (!updateWorldReady(client) || server == null || client.player == null) {
            reply.accept(BridgeProtocol.skyAck(action.id(), action.action(), "rejected", "Мир не открыт"));
            return;
        }
        UUID uuid = client.player.getUuid();
        server.execute(() -> {
            try {
                ServerPlayerEntity player = server.getPlayerManager().getPlayer(uuid);
                if (player == null) {
                    reply.accept(BridgeProtocol.skyAck(action.id(), action.action(), "rejected", "Игрок ещё не вошёл в мир"));
                    return;
                }
                dev.dirronlive.sky.SkyWorld.get(server).action(player, action, reply);
            } catch (RuntimeException e) {
                reply.accept(BridgeProtocol.skyAck(action.id(), action.action(), "rejected", "Ошибка в моде: " + e.getClass().getSimpleName()));
            }
        });
    }

    @Override
    public dev.dirronlive.sky.core.SkyStatus skyStatus() {
        if (!worldReady) return dev.dirronlive.sky.core.SkyStatus.ABSENT;
        return dev.dirronlive.sky.SkyWorld.lastStatus;
    }

    /** День, закат, ночь; ясно, дождь, гроза; остановить смену дня и погоды. */
    @Override
    public void world(BridgeProtocol.WorldSettings w) {
        IntegratedServer server = MinecraftClient.getInstance().getServer();
        if (server == null) return;
        server.execute(() -> {
            net.minecraft.server.world.ServerWorld world = server.getOverworld();
            if (w.time() != null) {
                long t = switch (w.time()) {
                    case "sunrise" -> 23000L;
                    case "sunset" -> 12000L;
                    case "night" -> 14000L;
                    case "midnight" -> 18000L;
                    default -> 1000L;
                };
                long day = world.getTimeOfDay() - Math.floorMod(world.getTimeOfDay(), 24000L);
                for (net.minecraft.server.world.ServerWorld sw : server.getWorlds()) sw.setTimeOfDay(day + t);
            }
            if (w.weather() != null) {
                int forever = 1_000_000;
                switch (w.weather()) {
                    case "rain" -> world.setWeather(0, forever, true, false);
                    case "thunder" -> world.setWeather(0, forever, true, true);
                    default -> world.setWeather(forever, 0, false, false);
                }
            }
            if (w.freeze() != null) {
                server.getGameRules().get(net.minecraft.world.GameRules.DO_DAYLIGHT_CYCLE).set(!w.freeze(), server);
                server.getGameRules().get(net.minecraft.world.GameRules.DO_WEATHER_CYCLE).set(!w.freeze(), server);
            }
        });
    }

    /** «[TikTok] Mira: привет» — в чат всем игрокам мира. */
    @Override
    public void chat(BridgeProtocol.Chat chat) {
        IntegratedServer server = MinecraftClient.getInstance().getServer();
        if (server == null) return;
        net.minecraft.util.Formatting nameColor = net.minecraft.util.Formatting.byName(chat.color());
        if (nameColor == null || !nameColor.isColor()) nameColor = net.minecraft.util.Formatting.GOLD;
        net.minecraft.text.Text line = net.minecraft.text.Text.empty()
                .append(net.minecraft.text.Text.literal("[TikTok] ").formatted(net.minecraft.util.Formatting.AQUA))
                .append(net.minecraft.text.Text.literal(chat.name()).formatted(nameColor, net.minecraft.util.Formatting.BOLD))
                .append(net.minecraft.text.Text.literal(": ").formatted(net.minecraft.util.Formatting.GRAY))
                .append(net.minecraft.text.Text.literal(chat.text()).formatted(net.minecraft.util.Formatting.WHITE));
        server.execute(() -> server.getPlayerManager().broadcast(line, false));
    }

    @Override
    public void countdown(BridgeProtocol.Countdown countdown) {
        IntegratedServer server = MinecraftClient.getInstance().getServer();
        if (server == null) return;
        server.execute(() -> ParkourWorld.get(server).countdown(countdown.id(), countdown.title(), countdown.seconds()));
    }
}
