package dev.dirronlive.sky;

import static net.minecraft.server.command.CommandManager.literal;

import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/** Режим полёта на элитрах «Небесный разлом» — серверная часть. */
public final class SkyMod implements ModInitializer {
    @Override
    public void onInitialize() {
        ServerLifecycleEvents.SERVER_STARTED.register(SkyMod::started);
        ServerLifecycleEvents.SERVER_STOPPING.register(SkyWorld::forget);
        ServerTickEvents.END_SERVER_TICK.register(server -> SkyWorld.get(server).tick());
        CommandRegistrationCallback.EVENT.register((dispatcher, registry, environment) -> {
            var sky = literal("sky");
            for (String cmd : new String[] {"start", "restart", "pause", "resume", "checkpoint", "stop", "training"}) {
                sky.then(literal(cmd).executes(c -> run(c, cmd)));
            }
            sky.then(literal("status").executes(SkyMod::status));
            sky.then(literal("log").executes(SkyMod::log));
            sky.then(literal("build").requires(SkyMod::owner).executes(SkyMod::build));
            sky.then(literal("reload").requires(SkyMod::owner).executes(SkyMod::reload));
            dispatcher.register(sky);
        });
    }

    static boolean owner(ServerCommandSource source) {
        return source.hasPermissionLevel(2) || source.getServer().isSingleplayer();
    }

    /** Запуск выделенного сервера, который строит мир DirronSky и выключается (сборка карты на GitHub). */
    public static final String BUILD_WORLD_PROPERTY = "dirronlive.buildSkyWorldAndStop";

    static void started(MinecraftServer server) {
        SkyWorld sw = SkyWorld.get(server);
        sw.load();
        if (sw.track() != null) sw.configureWorld();
        if (Boolean.getBoolean(BUILD_WORLD_PROPERTY)) {
            long t0 = System.currentTimeMillis();
            try {
                int blocks = sw.build(0, 0, 0);
                server.getGameRules().get(net.minecraft.world.GameRules.SPAWN_RADIUS).set(0, server);
                server.setDifficulty(net.minecraft.world.Difficulty.PEACEFUL, true);
                SkyWorld.LOG.info("DIRRON_SKY_BUILT rings={} sectors={} blocks={} ms={} problems={}",
                        sw.track().ringCount(), sw.track().sectors.size(), blocks, System.currentTimeMillis() - t0,
                        sw.track().problems().size());
            } catch (java.io.IOException e) {
                SkyWorld.LOG.error("DIRRON_SKY_FAILED {}", e.toString());
            }
            server.saveAll(false, true, true);
            server.stop(false);
        }
    }

    static int run(CommandContext<ServerCommandSource> c, String cmd) {
        ServerPlayerEntity player = c.getSource().getPlayer();
        if (player == null) {
            c.getSource().sendError(Text.literal("Команду выполняет игрок"));
            return 0;
        }
        SkyWorld.Result r = SkyWorld.get(c.getSource().getServer()).command(player, cmd);
        if (r.ok()) c.getSource().sendFeedback(() -> Text.literal(r.text()).formatted(Formatting.LIGHT_PURPLE), false);
        else c.getSource().sendError(Text.literal(r.text()));
        return r.ok() ? 1 : 0;
    }

    static int status(CommandContext<ServerCommandSource> c) {
        var s = SkyWorld.lastStatus;
        String text = "Небесный разлом: карта " + s.map() + ", " + s.phase() + ", сектор " + s.sector() + "/" + s.sectors()
                + ", кольцо " + s.ring() + "/" + s.rings() + ", время " + SkyWorld.time(s.ms() / 50) + ", ошибок " + s.errors()
                + (s.problem().isEmpty() ? "" : " · " + s.problem());
        c.getSource().sendFeedback(() -> Text.literal(text), false);
        return 1;
    }

    static int log(CommandContext<ServerCommandSource> c) {
        ServerPlayerEntity player = c.getSource().getPlayer();
        if (player == null) return 0;
        var lines = SkyWorld.get(c.getSource().getServer()).journal(player);
        if (lines.isEmpty()) c.getSource().sendFeedback(() -> Text.literal("Журнал действий пуст"), false);
        for (String line : lines.subList(Math.max(0, lines.size() - 15), lines.size())) {
            c.getSource().sendFeedback(() -> Text.literal(line).formatted(Formatting.GRAY), false);
        }
        return 1;
    }

    static int build(CommandContext<ServerCommandSource> c) {
        SkyWorld sw = SkyWorld.get(c.getSource().getServer());
        if (sw.track() != null) {
            c.getSource().sendFeedback(() -> Text.literal("Трасса уже есть в этом мире"), false);
            return 0;
        }
        try {
            int blocks = sw.build(SkyWorld.FALLBACK_X, SkyWorld.FALLBACK_Y, SkyWorld.FALLBACK_Z);
            c.getSource().sendFeedback(() -> Text.literal("«Небесные острова» построены: блоков " + blocks
                    + ". /sky start — старт").formatted(Formatting.LIGHT_PURPLE), true);
            return 1;
        } catch (java.io.IOException e) {
            c.getSource().sendError(Text.literal("Не удалось сохранить трассу: " + e.getMessage()));
            return 0;
        }
    }

    static int reload(CommandContext<ServerCommandSource> c) {
        SkyWorld sw = SkyWorld.get(c.getSource().getServer());
        sw.load();
        String text = sw.track() == null ? "Трассы нет: " + SkyWorld.lastStatus.problem()
                : "Трасса загружена: колец " + sw.track().ringCount();
        c.getSource().sendFeedback(() -> Text.literal(text), false);
        return 1;
    }
}
